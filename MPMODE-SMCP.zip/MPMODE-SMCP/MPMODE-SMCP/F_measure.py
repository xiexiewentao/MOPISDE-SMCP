import numpy as np
from collections import Counter
import copy
from partition import partition

def get_TP(A,B):

    clusB = partition(B)
    TP = 0
    for clus in clusB:
        for i in range(len(clus)):
            for j in range(i+1,len(clus)):
                if A[clus[i]] == A[clus[j]]:
                    TP += 1

    return TP

def get_FN(A,B):

    clusB = partition(B)
    FP = 0
    for clus in clusB:
        for i in range(len(clus)):
            for j in range(i + 1, len(clus)):
                if A[clus[i]] != A[clus[j]]:
                    FP += 1

    return FP

def get_FP(A,B):

    clusA = partition(A)
    clusB = partition(B)
    FN = 0
    for clus in clusA:
        for i in range(len(clus)):
            for j in range(i + 1, len(clus)):
                if B[clus[i]] != B[clus[j]]:
                    FN += 1

    return FN

def get_precision(A,B):

    TP = get_TP(A,B)
    FP = get_FP(A,B)
    precision = TP / (TP + FP)

    return precision

def get_recall(A,B):

    TP = get_TP(A,B)
    FN = get_FN(A,B)
    recall = TP / (TP + FN)

    return recall

def get_F_measure(A,B):

    TP = get_TP(A, B)
    FN = get_FN(A, B)
    FP = get_FP(A, B)

    #print("TP",TP)
    #print("FN",FN)
    #print("FP",FP)

    if TP + FP == 0:
        precision = 0
    else:
        precision = TP / (TP + FP)

    if TP + FN == 0:
        recall = 0
    else:
        recall = TP / (TP + FN)

    if precision + recall == 0:
        fm = 0
    else:
        fm = (2 * precision * recall) / (precision + recall)

    return precision,recall,fm

if __name__ == '__main__':


    #A = [0,0,1,1,2,1,1,1,1,1,1,1,1,1,1,0,1,0,0,2,1,1,1,1,2,1,1,1,1]
    #B = [0,0,1,0,1,1,0,0,0,1,0,0,2,2,2,0,0,0,0,1,2,0,0,0,1,2,2,0,2]
    A = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    B = [0,0,1,1,2,3,1,4,4,4,4,4,4,5,5,6,6,4,4,4,4,4,4,6,6,3,4,4,4,4,4,4,4,4,7,7,4,4,4,4,4,4,6,6,6]
    recall = get_recall(A,B)
    precision = get_precision(A,B)
    p,r,FM = get_F_measure(A,B)
    print(recall)
    print(precision)
    print(p)
    print(r)
    print(FM)

