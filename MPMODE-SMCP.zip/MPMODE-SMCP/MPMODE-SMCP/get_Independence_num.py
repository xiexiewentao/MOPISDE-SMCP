import numpy as np

def get_independence_num(X):
    cluster_num = len(X)
    inden = 0

    for i in range(cluster_num):
        clus = X[i]
        if len(clus) == 1:
            inden += 1

    return inden