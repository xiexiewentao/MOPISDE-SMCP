import networkx as nx
import numpy as np
import Graphhelper as gh
from partition import partition
from RRM import RRM
from copy import deepcopy


def instabcalculation(clus,G):

    Ca = 0
    Ce = 0
    #print(clus)
    for i in clus:
        for j in list(G.predecessors(i)):
            if j not in clus:
                Ca += 1
        for k in list(G.successors(i)):
            if k not in clus:
                Ce += 1

    if (Ca + Ce) == 0 :
        instab = 0
    else :
        instab = Ce / (Ca + Ce)

    return instab
#此处参数X为partition(X)
def get_Instability(X,G):

    cluster_num = len(X)
    instab = []
    count = 0

    for i in range(cluster_num):
        clus = X[i]
        instab_value = instabcalculation(clus,G)
        instab.append(instab_value)

    for i in instab:
        if i < 0.5 :
            count += 1
    instability = count / len(instab)

    #return MQ,reverse,direction,cluster_num,mutation_nodes
    return instability

if __name__ == '__main__':

    #G = gh.load_graph("dataset/Mozilla Firefox_matrix/browser.txt")

    #Y = [0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0]
    #X = [0,1,0,2,1,2,1,0,3,1,3,3,3,2,2,2,4,4,4,4]
    #X1 = [0,1,0,2,1,2,1,1,3,1,3,3,3,2,2,2,4,4,4,4]
    #X2 = [0,1,0,2,1,2,1,1,3,1,0,3,3,2,2,2,4,4,4,4]
    #X3 = [0,1,0,2,1,2,1,0,3,1,3,3,3,2,4,2,4,4,4,4]
    #X4 = [0,1,0,2,1,3,1,1,4,1,4,4,4,2,5,3,5,5,5,5]
    #X5 = [0,1,0,2,1,2,1,1,3,1,3,3,3,2,4,2,4,4,4,4]
    #X6 = [0,1,0,2,1,3,1,1,4,1,0,4,4,2,5,3,5,5,5,5]
    #X7 = [0,1,0,2,1,2,1,1,3,1,0,3,3,2,4,2,4,4,4,4]
    #X8 = [0,1,0,2,1,3,1,1,4,1,4,4,4,3,2,3,5,5,5,5]
    #X9 = [0,1,0,2,3,4,3,1,5,3,5,6,6,2,7,4,7,7,7,7]
    #X = [0,1,0,0,1,2,1,1,3,1,3,3,3,2,4,2,4,4,4,4]
    #print(get_Instability(partition(Y), G))
    #print(get_Instability(partition(X), G))
    #print(get_Instability(partition(X1), G))
    #print(get_Instability(partition(X2), G))
    #print(get_Instability(partition(X3), G))
    #print(get_Instability(partition(X4), G))
    #print(get_Instability(partition(X5), G))
    #print(get_Instability(partition(X6), G))
    #print(get_Instability(partition(X7), G))
    #print(get_Instability(partition(X8), G))
    #print(get_Instability(partition(X9), G))
    #X = [ 0,0,1,1,2,3,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,14,15,15,16,16,17,17,5,5,18,18,19,19,20,20,21,21,22,23,23]
    #X1 = [ 0,0,1,2,3,4,1,4,5,6,6,5,5,7,7,8,8,9,9,10,10,5,11,12,13,14,15,15,16,16,17,17,18,18,19,19,20,20,21,21,5,5,12,4,22]
    #X2 = [ 0,0,1,2,3,4,1,5,5,6,7,8,8,9,9,10,10,11,11,12,12,13,14,15,15,16,5,17,18,18,19,20,5,17,21,21,22,22,23,23,24,24,25,4,26]
    #print(get_Instability(partition(X), G))
    #print(get_Instability(partition(X1), G))
    #print(get_Instability(partition(X2), G))

    G = gh.load_graph("NSGA2/dataset/test.txt")
    X = [0, 0, 1, 0, 1, 1, 1, 1]
    Y = [0, 0, 0, 0, 1, 1, 1, 1]
    print(get_Instability(partition(X), G))
    print(get_Instability(partition(Y), G))