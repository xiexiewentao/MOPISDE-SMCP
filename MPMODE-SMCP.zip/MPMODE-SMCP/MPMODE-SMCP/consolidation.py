import random
import numpy as np
from TurboMQ import TurboMQ
from C2C import C2CCalculation
from RRM import RRM

# 按社区个数对社区的标签进行降序排列
def sort_comm(ind):
    b = set(ind)
    c = {}
    d = []
    for i in b:
        num = sum(ind==i)
        c[i] = num
    for j in c:
        d.append(j)

    return sorted(d,reverse=True)

#合并两个社区:合并标签为sort_C[i]和sort_C[j]的两个社区
def merge(i,j,sort_C,ind):
    nodes = [k for (k, v) in enumerate(ind) if v == sort_C[j]]
    for node in nodes:
        ind[node]=sort_C[i]
    newind=ind.copy()
    return newind

# 二级社区合并策略
def consolidation(G,ind,k,chan,fit1,fit2):
    scoresms[i] = C2CCalculation(male_swarm[i, :],B,thcvg)
    scorestq[i],multed[i] = TurboMQ(female_swarm[i, :], G)
    commlen = len(modu1)-1
    order_C = np.zeros(len(modu1))
    for i in range(len(modu1)):
        order_C[i] = i
    index = np.argsort(modu1, axis=0)[::-1]
    #for i in range(commlen+1):
        #Xnew[i, :] = X[index[i], :]
    order_C = order_C[index]
    i = commlen-2
    j = commlen//2
    newind = ind.copy()
    oldind = ind.copy()
    while i>0:
        newind=oldind.copy()
        if j < i and j >= 0 :
            i1 = np.random.randint(j,i)  # 随机选取k个节点
        else:
            i1 = np.random.randint(0, i)
        i2 = np.random.randint(i,commlen-1)
        newind=merge(i1,i2,order_C,newind) #合并两个社区（大的和小的合并）
        fitness2, modu2 = cal_Q(partition(newind), G)
        if fitness2>fitness1: # 如果finess变大则留下，否则舍去
            oldind = newind.copy()
            fitness1 = fitness2
        i -= 1
        j -= 1
    return oldind,fitness1




def consolidation2(G,ind):
    #按社区包含节点的个数降序排序
    sort_C=sort_comm(ind)
    newind = ind.copy()
    s=len(sort_C) #社区个数
    i = s-1
    k = s-2
    while k> 1:
        j = np.random.randint(0,k)+1
        k = np.random.randint(0,j)
        oldind = ind.copy()
        ind = merge(i, j, sort_C, ind)  # 合并两个社区（大的和小的合并）
        if cal_Q(partition(ind), G) > cal_Q(partition(oldind), G):  # 如果finess变大则留下，否则舍去
            oldind = ind.copy()
            newind = ind.copy()
            break
        else:
            ind = oldind.copy()
            newind = oldind.copy()

        k -= 1

    return newind



def consolidation1(G,ind,curr):
    #按社区包含节点的个数降序排序
    fitness1,modu1 = cal_Q(partition(ind),G)
    commlen = len(modu1)-1
    order_C = np.zeros(len(modu1))
    for i in range(len(modu1)):
        order_C[i] = i
    index = np.argsort(modu1, axis=0)[::-1]
    #for i in range(commlen+1):
        #Xnew[i, :] = X[index[i], :]
    order_C = order_C[index]
    i = commlen//2
    newind = ind.copy()
    oldind = ind.copy()
    cur = int(curr)
    while i>0:
        newind=oldind.copy()
        i1 = np.random.randint(0, i)
        i2 = np.random.randint(0, i)
        #print("curr",cur,i)
        newind=merge(i1,i2,order_C,newind) #合并两个社区（大的和小的合并）
        fitness2, modu2 = cal_Q(partition(newind), G)
        if fitness2>fitness1: # 如果finess变大则留下，否则舍去
            oldind = newind.copy()
            fitness1 = fitness2
        i -= 1
    return oldind,fitness1
