import numpy as np
import random
import Graphhelper as gh
from Initial_with_MLPA import LPA
from TurboMQ import TurboMQ
from RRM import RRM
from MS import MS
from C2C import C2CCalculation
from RRM import indiRRM

'''

编码方式：
    编码：     [1,1,1,1,2,2,2]
    数组下标：   0,1,2,3,4,5,6
    即表示点{0,1,2,3}在社区1，点{4,5,6}在社区2

'''

def mutate(population,G,mutationProbability,multi_class,change,time1,time2):
    population1 = population.copy()
    dim = len(G.nodes)
    if change == 0:
        #按MUTATE函数进行变换
        offspringMutationProbability = random.uniform(0.0, 1.0)
        if offspringMutationProbability < mutationProbability:
            #按全部MUTATION函数变换
            for j in range(dim):
                newLabel = int(multi_class[j])
                if newLabel != -1:
                    population1[j] = newLabel
        elif offspringMutationProbability < 1:
            # 按部分MUTATION函数变换
            for j in range(dim):
                newLabel = int(multi_class[j])
                if newLabel != -1:
                    mutationProbability = random.uniform(0.0, 1.0)
                    if mutationProbability < 0.5:
                        population1[j] = newLabel

            mutationIndex = random.randint(0, dim - 1)
            neighbors = list(G.successors(mutationIndex)) + list(G.predecessors(mutationIndex))
            neighbor = random.choice(neighbors)
            population1[mutationIndex] = population1[neighbor]

    elif change == 1:
        for i in range(time1):
            mutationIndex = random.randint(0, dim - 1)
            neighbors = list(G.successors(mutationIndex)) + list(G.predecessors(mutationIndex))
            neighbor = random.choice(neighbors)

            population1[mutationIndex] = population1[neighbor]

    else:
        for i in range(time1):
            mutationIndex = random.randint(0, dim - 1)
            neighbors = list(G.successors(mutationIndex)) + list(G.predecessors(mutationIndex))
            time2 = min(time2,len(set(neighbors)))
            for j in range(time2):
                neighbor = random.choice(neighbors)
                population1[neighbor] = population1[mutationIndex]

    return population1

def mutatio(G,ind,p_mu,mute):
    oldind = ind.copy()  # 在变异之前保存原来的个体
    newind = ind.copy()

    i=0
    for cf in mute:
        set1 = G.adj[cf]
        for j in set1:
            if newind[cf] != newind[j]:
                x = np.random.rand()
                if x < 0.5:
                    newind[cf] = newind[j]
                else:
                    set2 = []
                    for k in G.nodes:
                        if newind[k] == newind[cf]:
                            set2.append(k)
                    for k in set2:
                        newind[k] = newind[j]
                break

        newind = indiRRM(newind)

    return oldind

def mutated(G,ind,freq):
 # 在变异之前保存原来的个体
    newind = ind.copy()
    if freq == []:
        for i in range(2):
            fre = random.sample(range(0, len(ind) - 1), round(4))
            freq.append(fre)
    for cf in freq:#按集合一个元素的邻居进行变异
        dim = len(cf)
        if dim>1:
            mutationIndex = random.randint(0, dim - 1)
        else:
            mutationIndex = 0
        neighbors = list(G.successors(cf[mutationIndex])) + list(G.predecessors(cf[mutationIndex]))
        if len(neighbors) != 0:
            neighbor = random.choice(neighbors)
            for k in cf:  # 对第i个节点及其邻居执行joint-gene变异
                newind[k] = newind[neighbor]
            newind = indiRRM(newind)
        #print("mutated",oldind,newind)

    return newind

def mutated1(G,ind,freq):
 # 在变异之前保存原来的个体
    newind = ind.copy()

    for cf in freq:#按集合一个元素的邻居进行变异
        dim = len(cf)
        if dim>1:
            mutationIndex = random.randint(0, dim - 1)
        else:
            mutationIndex = 0
        neighbors = list(G.successors(cf[mutationIndex])) + list(G.predecessors(cf[mutationIndex]))
        neighbor = random.choice(neighbors)
        for k in cf:  # 对第i个节点及其邻居执行joint-gene变异
            newind[k] = newind[neighbor]
        newind = indiRRM(newind)
        #print("mutated",oldind,newind)

    return newind


def mutation(G,ind,p_mu,freq):
    oldind=ind.copy()  # 在变异之前保存原来的个体
    newind = ind.copy()
    i=0
    while i<len(G.nodes):
        x=np.random.rand() #随机生成一个数[0,1],x控制变异单个或全体
        set1 = G.adj[i]
        set2 = []
        for j in set1:
            if x<p_mu:
                if set1 != []:
                    f = np.random.randint(0,len(set1))
                    for k in freq:
                        if newind[k] == newind[i]:
                            newind[k] = newind[set1[f]]
            else: # 对第i个节点及其邻居执行joint-gene变异
                for k in (set2):
                    ind[k] = ind[i]
        for k in range(2):
            if k==0:
                score1, rever1, direct1, multi_clas1, X1, cluster_num1= MS(newind, G)
                score2, rever2, direct2, multi_clas2, X2, cluster_num2 = MS(oldind, G)
            else:
                score1 = TurboMQ(newind, G)
                score2 = TurboMQ(oldind, G)
            if score1 < score2:
                newind = oldind.copy()

        i += 1
    return newind


if __name__ == '__main__':

    G = gh.load_graph("NSGA2/dataset/rcs.txt")
    dim = len(G.nodes)
    popsize = 5
    keep = 2
    fitness = np.ones(popsize) * float("inf")
    mutationProbability = 0.8
    X = LPA(G,popsize, dim, 3)
    X = RRM(X,popsize,dim)
    print(X)
    for i in range(popsize):
        fitness[i] = TurboMQ(X[i, :], G)
    newX = mutation(X,G,popsize,dim,mutationProbability,keep)
    print(newX)
