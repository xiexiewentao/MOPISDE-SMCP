# Semantic-Dependency-Data-Set
Extracted  Semantic Dependency Graph for Mozilla Firefox 3.7
