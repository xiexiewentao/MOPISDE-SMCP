import numpy as np
import Graphhelper as gh
import random
from TurboMQ import TurboMQ,NewTurboMQ
from partition import partition
import collections


def get_max_neighbor_label(G, X, node):
    m = collections.defaultdict(int)    #以键值对的方式计数
    neighbors = (list(G.predecessors(node))+list(G.successors(node)))
    for neighbor_index in neighbors:
        neighbor_label = X[neighbor_index]
        m[neighbor_label] += 1   #neighbor_label出现一次就加1
    max_v = max(m.values())
    # m.items() = ([(neigbor_lable1,出现次数),(neigbor_lable2,出现次数)...])
    #print("m",m)
    return [item[0] for item in m.items() if item[1] == max_v] #如果有多个max_v就返回list




def gbestLS(gbest,G):

    dim = len(G.nodes)
    gbest_clus_num = max(gbest)+1
    #node = random.randint(0, dim-1)
    #neighbors = (list(G.predecessors(node))+list(G.successors(node)))
    #mutation = random.sample(neighbors, 1)
    #for i in mutation:
    #    if gbest[node] != gbest[i]:
    #        gbest[node] = gbest[i]

    #node_index = random.randint(0, gbest_clus_num - 1)
    node_index = 2
    nodes1 = [j for (j, v) in enumerate(gbest) if v == node_index]
    neighbor1 = []
    for i in nodes1:
        neighbors = list(G.predecessors(i)) + list(G.successors(i))
        for j in neighbors:
            if j not in nodes1:
                neighbor1.append(j)
    print(nodes1)
    print(neighbor1)
    for i in range(gbest_clus_num):
        intra = []
        inter = []
        neighbor2 = []

        if i != node_index:
            nodes2 = [j for (j, v) in enumerate(gbest) if v == i]

        print(nodes2)
        for j in nodes2:
            neighbors = list(G.predecessors(j)) + list(G.successors(j))
            for k in neighbors:
                if k not in nodes2:
                    neighbor2.append(k)
        print(neighbor2)
        intra = (len([node for node in neighbor1 if node in nodes2]) \
                + len([node for node in neighbor2 if node in nodes1]))/2
        print("intra",intra)
        inter = len(neighbor1)+len(neighbor2)
        print("inter",inter)
        print(intra/inter)


    #求所有分区的邻居
    gbest_clus = partition(gbest)
    inter2 = []
    for i in gbest_clus:
        inter1=[]
        for j in i:
            node = list(G.predecessors(j)) + list(G.successors(j))
            for k in node:
                if k not in i:
                    inter1.append(k)
        inter2.append(inter1)
    print(inter2)

    #求交集和差集
    for i in inter2:
        for j in inter2:
            if i != j:
                comm = list(set(i).intersection(set(j)))



    return gbest

def gbestLS1(gbest,G):

    ind = gbest.copy()
    dim = len(G.nodes)
    gbest_clus_num = max(ind)+1
    mutationProbability = random.uniform(0.0, 1.0)
    change_nodes = []
    fgbest = TurboMQ(partition(gbest), G)
    score = 0
    for i in range(dim):
        label = ind[i]
        max_labels = get_max_neighbor_label(G, X, i)
        if (label not in max_labels):
            change_nodes.append(i)
            print(i,max_labels)
    print("change_nodes",change_nodes)
    if change_nodes != []:
        for i in change_nodes:
            neighbors = (list(G.predecessors(i))+list(G.successors(i)))
            mutation = random.sample(neighbors, 1)
            for j in mutation:
                if (ind[i] != ind[j] and mutationProbability < 0.7):
                    ind[i] = ind[j]

            nodes = random.sample(change_nodes, 2)
            clus = [i for (i, v) in enumerate(ind) if v == ind[nodes[0]]]
            for i in clus:
                ind[i] = ind[nodes[1]]
    score = TurboMQ(partition(ind),G)

    return ind

if __name__ == '__main__':

    G = gh.load_graph("NSGA2/dataset/mtunis.txt")
    X = [0,1,0,2,1,2,1,1,3,1,3,3,3,2,4,2,4,4,4,4]
    #X1 = [0,1,0,2,1,2,1,1,3,1,3,3,3,2,4,2,4,4,4,4]
    #print(TurboMQ(partition(X),G))
    gbestLS1(X, G)
    #print(TurboMQ(partition(gbestLS(X, G)),G))