import Graphhelper as gh
import numpy as np
import random
import math
from Get_best_neighbor import get_best_neighbor

'''
    来自文献：An Evolutionary Multiobjective Approach for Community Discovery in Dynamic Networks
    初始化种群：
    编码：     [3,2,1,1,5,4,5]
    数组下标：   0,1,2,3,4,5,6
    即表示存在边：(0,3),(1,2),(2,1),(3,1),(4,5),(5,4),(6,5)
    边的选取规则：
    1、没有邻居：选择自己
    2、有邻居且有最好邻居：选择最好邻居
    3、有邻居但没有最好邻居：随机选择一个邻居
'''

def initialization(popsize,dim,G):

    X = np.ones((popsize,dim)) * float("inf") #初始化数组，因为0也代表一个结点，所以用“inf”来初始化
    chrom = np.ones(dim) * float("inf")
    prob = 0.5
    for i in range(popsize):
        for j in range(dim):
            if (len(list(G.successors(j))) == 0):
                chrom[j] = j    #没有邻居就指向自己
            else:
                if (random.random() < prob or get_best_neighbor(j,G) == float("inf")):
                    #这里直接随机取一个邻居
                    position = random.choice(list(G.successors(j)))
                else:
                    position = get_best_neighbor(j,G)
            chrom[j] = position
        X[i,:] = chrom
    return X


if __name__ == "__main__":
    G = gh.load_graph("NSGA2/dataset/rcs.txt")
    popsize = 10
    X = initialization(popsize,len(G.nodes),G)
    print(X)
