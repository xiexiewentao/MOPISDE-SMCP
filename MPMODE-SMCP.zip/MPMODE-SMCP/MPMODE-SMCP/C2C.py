import numpy as np
from collections import Counter
import copy
from partition import partition

def getCluster(X):
    cluster = []
    visit = [0] * len(X)
    for i in range(len(X)):
        if visit[i] == 0:
            temp = X[i]
            nodelist = []
            for j in range(i, len(X)):
                if X[j] == temp:
                    nodelist.append(j)
                    visit[j] = 1
            cluster.append(nodelist)
    return cluster

def c2cCalculation(c1,c2):

    EntitNumofC1 = len(c1)
    EntitNumofC2 = len(c2)
    count2 = 0

    for i in range(EntitNumofC1):
        for j in range(EntitNumofC2):
            if c1[i] == c2[j]:
                count2 += 1

    c2c = count2 / max(EntitNumofC1,EntitNumofC2)
    return c2c

def SimCalculation(ClusterA,ClusterB,ClusterNumofA,ClusterNumofB,thcvg):

    count1 = 0
    for i in range(ClusterNumofA):
        all_c2c = []
        for j in range(ClusterNumofB):
            all_c2c.append(c2cCalculation(ClusterA[i],ClusterB[j]))
        if max(all_c2c) > thcvg:
            count1 += 1

    return count1


def C2CCalculation(A,B,thcvg):

    ClusterNumofA = len(set(A))
    ClusterNumofB = len(set(B))

    ClusterA = getCluster(A)
    ClusterB = getCluster(B)

    simAwithB = SimCalculation(ClusterA,ClusterB,ClusterNumofA,ClusterNumofB,thcvg)

    C2C = simAwithB / ClusterNumofA

    return C2C

if __name__ == '__main__':
    A = [0,0,1,2,1,3,3,3,4,5,6,7,5,5,8,0,9,10,0,11,0,12,8,0,0,3,13,13,14,9,4,10,15,15,0,12,11,16,17,17,18,19,14]
    B = [0,0,1,1,1,2,3,4,3,3,3,3,5,3,3,3,3,3,3,3,3,3,3,3,3,4,5,5,5,3,3,3,5,5,3,3,3,3,6,6,3,3,5]
    thcvg = 0.33
    print(partition(A),len(partition(A)))
    print(partition(B),len(partition(B)))
    #A = [0,0,1,1,2,1,1,1,1,1,1,1,1,1,1,0,1,0,0,2,1,1,1,1,2,1,1,1,1]
    #B = [0,0,1,0,1,1,0,0,0,1,0,0,2,2,2,0,0,0,0,1,2,0,0,0,1,2,2,0,2]
    cvg = C2CCalculation(A,B,thcvg)
    print(cvg)

