import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import matrix_to_graph as m2g
import Graphhelper as gh
import copy
from matplotlib.patches import Ellipse

colors = ['#ff4040', '#4876ff', '#add8e6', '#ffff00','#c0ff3e','#ffc1c1','#a0522d'] * 100
shape = ['o', '^', 's', 'd'] * 100
options = {'font_family': 'serif', 'font_weight': 'semibold', 'font_size': '18', 'font_color': '#000000'}
savefig_path = 'NSGA2/dataset/Graph/'

#类别中心
def com_postion(size, scale=1, center=(0, 0), dim=2):
    # generat the postion for each nodes in a community
    num = size
    center = np.asarray(center)
    theta = np.linspace(0, 1, num + 1)[:-1] * 2 * np.pi
    theta = theta.astype(np.float32)
    pos = np.column_stack([2.5*np.cos(theta), 2*np.sin(theta), np.zeros((num, 0))])
    pos = scale * pos + center

    return pos

#节点中心
def node_postion(one_com, scale=1, center=(0, 0), dim=1):
    # generat the postion for each nodes in a community
    num = len(one_com)
    node = list(one_com)
    center = np.asarray(center)
    theta = np.linspace(0, 1, num + 1)[:-1] * 2 * np.pi
    theta = theta.astype(np.float32)
    pos = np.column_stack([1.2*np.cos(theta), np.sin(theta), np.zeros((num, 0))])
    pos = scale * pos + center
    node_array = pos
    pos = dict(zip(node, pos))

    return pos,node_array

#画原始网络图，只用传入nx.Graph
def drawing_original_network(G):

    plt.figure(figsize=(10, 10))
    pos = nx.shell_layout(G)
    nx.draw(G, pos, **options)
    node_labels = nx.get_node_attributes(G, 'label')
    nx.draw_networkx_labels(G, pos, labels = node_labels, **options)
    nx.draw_networkx_nodes(G, pos, node_size=600, node_color="#034b61",node_shape='d')
    plt.savefig(savefig_path + 'original_network.png', format='png', dpi=500)
    plt.show()

#画聚类结果图
def drawing_cluster_result(community,G):

    cluster = []
    visit = [0] * len(community)
    for i in range(len(community)):
        if visit[i] == 0:
            temp = community[i]
            nodelist = []
            for j in range(i,len(community)):
                if community[j] == temp:
                    nodelist.append(j)
                    visit[j] = 1
            cluster.append(nodelist)

    num_cluster = len(cluster)

    # find intra_com links
    intra_links = {}
    for i in range(num_cluster):
        intra_links[i] = []

    for link in nx.edges(G):
        for i in range(num_cluster):
            if (link[0] in cluster[i]) & (link[1] in cluster[i]):
                intra_links[i].append(link)

    com_center = com_postion(num_cluster, scale=3)  # print(com_center)
    pos = dict()
    #获取节点中心位置以及类别边框（虚线椭圆）的长和宽
    cluster_width_height = []
    for val in range(num_cluster):
        nodes_pos,nodes_array = node_postion(cluster[val], scale=1.3, center=com_center[val])
        cluster_width_height.append(list(np.amax(nodes_array, axis=0) - np.amin(nodes_array, axis=0)))
        pos.update(nodes_pos)

    fig = plt.figure(figsize=(15, 15))
    #画类别边框
    ax = fig.add_subplot(111)
    for val in range(num_cluster):
        if len(cluster[val]) == 1:
            node_pos, node_array = node_postion(cluster[val], scale=1.3, center=com_center[val])
            ell1 = Ellipse(xy=node_array[0], width=cluster_width_height[val][0] + 1.5,
                           height=cluster_width_height[val][1] + 1.5,
                           linestyle='--', linewidth=2, edgecolor='k', facecolor='w')

        else:
            ell1 = Ellipse(xy=com_center[val], width=cluster_width_height[val][0] + 1.5,
                           height=cluster_width_height[val][1] + 1.5,
                           linestyle='--', linewidth=2, edgecolor='k', facecolor='w')

        ax.add_patch(ell1)

    #节点相关设置
    for val in range(num_cluster):
        nx.draw_networkx_nodes(G, pos, node_size=650, nodelist=list(cluster[val]), node_color=colors[val],node_shape=shape[val])
        #nx.draw_networkx_edges(G, pos, alpha=0.7, edgelist=intra_links[val], width=1.5)
    #nx.draw(G, pos, **options)
    #边的相关设置
    nx.draw_networkx_edges(G, pos, width=1, arrowsize=25,edge_color='#404040')
    #标签相关设置
    node_labels = nx.get_node_attributes(G, 'label')
    label_pos = copy.deepcopy(pos)
    for label_value in label_pos.values():
            label_value[0] = label_value[0] + 0.5
            label_value[1] = label_value[1] - 0.5
    nx.draw_networkx_labels(G, label_pos,labels=node_labels, **options)

    plt.axis("off")
    #plt.savefig(savefig_path + 'clustering_result.png', format='png', dpi=500)
    plt.show()

if __name__ == '__main__':

    G = gh.load_graph("NSGA2/dataset/mtunis.txt")
    #drawing_original_network(G)
    result = [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2]
    community = [0,1,2,3,1,1,1,4,2,1,2,5,5,3,5,5,5,5,5,5]
    community1 = [0,1,0,2,1,1,1,1,3,1,0,4,2,2,4,1,4,4,4,4]
    #community1=[0, 1, 0, 2, 1, 3, 1, 1, 4, 1, 4, 4, 4, 2, 5, 3, 5, 5, 5, 5]
    drawing_cluster_result(community,G)
    #drawing_cluster_result(community1, G)