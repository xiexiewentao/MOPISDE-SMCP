import numpy as np
import networkx as nx
import random
import collections
import Graphhelper as gh
import matrix_to_graph as m2g
from RRM import RRM
np.set_printoptions(threshold=np.inf)
from random import choice
from TurboMQ import NewTurboMQ,TurboMQ
from partition import partition
from MS import get_similarity

def get_sim(G):
    dim = len(G.nodes)
    sim_matrix = np.zeros([dim, dim])
    for i in range(dim):
        for j in range(dim):
            if i != j :
                sim_matrix[i, j] = get_similarity(i, j, G)
            else:
                sim_matrix[i, j] = 0

    for i in range(dim):
        for j in range(dim):
            if sim_matrix[i, j] > 1 :
                print("sim > 1",i,j)

    return sim_matrix

def LPA_NEW(G,popsize,p):

    sim = get_sim(G)
    dim = len(G.nodes)
    neighbor = []
    X = float("inf") * np.ones((popsize, dim))
    for i in range(popsize):
        for j in range(dim):
            X[i, j] = j

    for i in range(popsize):
        for j in range(dim):
            if random.random() > p :
                index = np.argmax(sim[j])
                X[i,j] = X[i,index]
            else:
                for k in range(dim):
                    if sim[j,k] > 0 :
                        neighbor.append(k)
                if neighbor != []:
                    index = random.choice(neighbor)
                    X[i, j] = X[i, index]

    return X

if __name__ == '__main__':

    G = m2g.load_graph("NSGA2/dataset/Mozilla Firefox_matrix/accessible.txt")
    popsize = 30
    X = LPA_NEW(G, popsize,0.1)
    MQ = []
    #print("befor",X)

    for i in range(popsize):
        X[i, :] = RRM(X[i, :])
    #print(X)

    for i in range(popsize):
        MQ.append(NewTurboMQ(X[i],partition(X[i]),G))
    print(MQ)
    print("mean", np.mean(MQ))
    print("median", np.median(MQ))
    print("best", max(MQ))
