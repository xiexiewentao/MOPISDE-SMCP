import scipy.io as scio

data = scio.loadmat("NSGA2/dataset/Call/browser.mat")
#matrix = data[type]
print(data)