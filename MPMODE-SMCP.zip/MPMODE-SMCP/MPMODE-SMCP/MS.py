import numpy as np
import Graphhelper as gh
import math
import copy
from partition import partition



def index_of(a, list):
    index = []
    for i in range(0, len(list)):
        if list[i] == a:
            index.append(i)
    if len(index) != 0:
        return index
    else:
        return False


def getout_global_modules(X, G):

    global_modules = []
    for i in X:
        if ((G.in_degree(i)) > 1 and (G.out_degree(i) == 0)):
            global_modules.append(i)
            #print("gl",i)

    #if len(global_modules) != 0:
    #for i in global_modules:
        #X.remove(i)
            #print("gll", i)

    newX = copy.deepcopy(X)

    #newG = gh.clone_graph(G)
    #for i in global_modules:
        #newG.remove_node(i)

    return newX, global_modules


def get_gamma(c, module, newG):
    gamma = []
    if c == 'in':
        predecessors = list(newG.predecessors(module))
        for i in predecessors:
            gamma.append(i)
    if c == 'out':
        successors = list(newG.successors(module))
        for i in successors:
            gamma.append(i)
    gamma.append(module)

    return gamma


def get_similarity(M1, M2, newG):
    M1_in = get_gamma('in', M1, newG)
    M2_in = get_gamma('in', M2, newG)
    M1_out = get_gamma('out', M1, newG)
    M2_out = get_gamma('out', M2, newG)

    M1_in_and_M2_in = list(set(M1_in).intersection(M2_in))
    M1_out_and_M2_out = list(set(M1_out).intersection(M2_out))
    M1_in_or_M1_out = list(set(M1_in).union(set(M1_out)))
    M2_in_or_M2_out = list(set(M2_in).union(set(M2_out)))

    similarity = (len(M1_in_and_M2_in) + len(M1_out_and_M2_out)) / math.sqrt(
        len(M1_in_or_M1_out) * len(M2_in_or_M2_out))

    return similarity


def get_tightness(cluster,global_module, newG,mutated):
    S_in = []
    S_out = []
    has_visited = []

    for i in cluster:
        has_visited.append(i)
        #print("i",i)
        if i not in global_module:
            temp = list(set(cluster).difference(set(has_visited)))
            for j in temp:
                S_in.append(get_similarity(i, j, newG))

    for i in cluster:
        if (i not in global_module):
            change = 0
            for j in newG.nodes:
                if ((j not in cluster) and (j not in global_module) and (
                (newG.has_edge(i, j) or (newG.has_edge(j, i))))):
                    S_out.append(get_similarity(i, j, newG))
                    change += 1
            if change == 0:
                mutated.append(i)
    if ((sum(S_in) + sum(S_out))!=0):
        tightness = sum(S_in) / (sum(S_in) + sum(S_out))
    else:
        tightness = 0

    return tightness


def MS(XX, G):
    X = XX.copy()
    X,global_module = getout_global_modules(X,G)
    #print(X,global_module)
    cluster = partition(X)
    cluster_num = len(cluster)
    tightness = []
    mutated = []

    #print("global", global_module)
    for i in range(cluster_num):
        #print("cls", cluster[i])
        tightness.append(get_tightness(cluster[i],global_module, G,mutated))
    #print("MU",mutated)
    ms = sum(tightness)
    return ms

if __name__ == '__main__':

    X = [0,0,0,0,1,1,1,1]
    Y = [0,0,1,0,1,1,1,1]
    X1 = [0,1,0,2,1,2,1,1,3,1,3,3,3,2,2,2,4,4,4,4]
    X2 = [0,1,0,2,1,2,1,0,3,1,3,3,3,2,4,2,4,4,4,4]
    X3 = [0,1,0,2,1,3,1,1,4,1,4,4,4,2,5,3,5,5,5,5]
    X4 = [0,1,0,2,1,2,1,1,3,1,3,3,3,2,4,2,4,4,4,4]
    X5 = [0,1,0,2,1,3,1,1,4,1,4,4,4,3,2,3,5,5,5,5]
    G =gh.load_graph("NSGA2/dataset/test.txt")
    print(MS(X,G))
    print(MS(Y, G))
    #print(MS(X2, G))
    #print(MS(X3, G))
    #print(MS(X4, G))
    #print(MS(X5, G))
