import collections
import random
import numpy as np
from TurboMQ import NewTurboMQ,TurboMQ
import Graphhelper as gh
from RRM import RRM
from partition import partition
np.set_printoptions(threshold=np.inf)

'''
编码方式：
    编码：     [1,1,1,1,2,2,2]
    数组下标：   0,1,2,3,4,5,6
    即表示点{0,1,2,3}在社区1，点{4,5,6}在社区2

DLPA的处理过程与LPA相同，只是标签选择规则不同。
结点i的标签选择规则：
    对于i的入度结点j：
        计算每个入度结点j的权重：1-k(in)(i)*k(out)(j)/k(i)k(j)
    对于i的出度结点j：
        计算每个出度结点j的权重：1-k(out)(i)*k(in)(j)/k(i)k(j)
    其中k(in)(i)和k(out)(i)是节点i的入度和出度,k(i)是结点i的总边数
    选择权重大的边进行传播

'''

def com_unfroze(G):
    n = len(G.nodes)
    froze = []
    unfroze = []
    du = G.degree()

    for i in range(n):
        if G.degree(i) != 0:
            unfroze.append(i)#print("i",i,neibors)
        else:
            froze.append(i)
    return unfroze,froze

def can_stop(G,popsize,dim,X):

    # 所有结点的标签都和它邻居中权重最大的标签一致时停止
    for i in range(popsize):
        for j in range(dim):
            label = X[i,j]
        #neighbor = list(G.successors(i)) + list(G.predecessors(i))
        #for j in neighbor:
            max_weight_labels = get_max_weight_node(G, X[i,:], j)
            if (label != any(max_weight_labels)):
                return False
    return True

def get_max_weight_node(G, X, i):

    indegree = list(G.predecessors(i))
    in_weight = [0] * len(G.nodes)
    max_in_weight = 0
    max_in_weight_label = []
    outdegree = list(G.successors(i))
    out_weight = [0] * len(G.nodes)
    max_out_weight = 0
    max_out_weight_label = []

    ki = G.in_degree(i) + G.out_degree(i)
    if (indegree) :
        for j in indegree:
            kj = G.in_degree(j) + G.out_degree(j)
            in_weight[j] = 1 - (G.in_degree(i) * G.out_degree(j)) / (ki * kj)
        max_in_weight = max(in_weight)
        max_in_weight_label.append(X[in_weight.index(max_in_weight)])

    if (outdegree) :
        for j in outdegree:
            kj = G.in_degree(j) + G.out_degree(j)
            out_weight[j] = 1 - (G.out_degree(i) * G.in_degree(j)) / (ki * kj)
        max_out_weight = max(out_weight)
        max_out_weight_label.append(X[out_weight.index(max_out_weight)])

    if max_in_weight > max_out_weight :
        return max_in_weight_label
    else:
        return max_out_weight_label

def init(G,unfroze):
    n = len(G.nodes)
    nodeSect = []

    ind = np.empty(n)
    ind.fill(np.inf)
    label = 0
    set3 = []
    for k in unfroze:
        neibor1 = (list(G.predecessors(k)) + list(G.successors(k)))
        if ind[k] == np.inf:
            for neibor in neibor1:
                neibor2 = (list(G.predecessors(neibor)) + list(G.successors(neibor)))
                set1 = list(set(neibor1).intersection(neibor2))
                if set1 != []:
                    set2 = set(set1).union([neibor])
                    set2 = set(set2).union([k])  # print("set2",set2) #print("n",nodeInsect)
                    if set2 not in nodeSect:
                        nodeSect.append(set2)
                        for j in set2:
                            ind[j] = label
                        label += 1

    len1 = len(nodeSect)#print("first label",label,newind )
    sect = []
    for i in range(len1):
        sect.append(list(nodeSect[i]))
    nodeSect = sect.copy()
    return nodeSect

def populate_label(G,popsize,dim,X):

    # 访问指定长度的随机序列
    #visitSequence = random.sample(G.nodes(), len(G.nodes()))
    #for i in visitSequence:
    for i in range(popsize):
        for j in range(dim):
            label = X[i,j]
        #获取权重最大的结点序列
            max_weight_labels = get_max_weight_node(G,X[i,:],j)
            if (label != any(max_weight_labels)):
                newLabel = random.choice(max_weight_labels)
                X[i,j] = newLabel
    return X

def DLPA(G,popsize,dim,max_iter):
    n = len(G.nodes)
    dim = n
    du = G.degree
    unfroze, froze = com_unfroze(G)

    # 初始化标签，每个结点携带一个唯一的标签
    X = np.ones((popsize,dim)) * float("inf")
    for i in range(popsize):
        for j in range(dim):
            X[i, j] = j

    #initial = init(G, unfroze)
    #kk = len(initial)
    #for i in range(popsize):
    #    label = n
    #    for ii in range(kk):
    #        for j in initial[ii]:
    #            X[i, j] = label
    #        label += 1
    # 更新标签
    iter_time = 0
    while (not can_stop(G,popsize,dim,X) and iter_time < max_iter):
        populate_label(G,popsize,dim,X)
        iter_time += 1

    return X

if __name__ == '__main__':

    G = gh.load_graph("NSGA2/dataset/rcs.txt")
    Max_item = 2
    popsize = 50
    dim = len(G.nodes)
    X = DLPA(G,popsize,dim,Max_item)
    MQ = []
    for i in range(popsize):
        cs = RRM(X[i, :])
        MQ.append(TurboMQ(partition(cs), G))
    print(MQ)


    #X = float("inf") * np.ones(len(G.nodes))
    #for i in range(len(G.nodes)):
    #    X[i] = i
    #print(X)
    #x = get_max_weight_node(G, X, 5)
    #print(x)
