import collections
import random
import numpy as np
import networkx as nx
import matrix_to_graph as m2g
from TurboMQ import get_sum_of_intra_edge,get_sum_of_inter_edge,distMQ,distMQ1,distMQ2,distMQ3
from Ca_and_Ce import get_Instability
from MS import MS
from RRM import RRM
from TurboMQ import TurboMQ,NewTurboMQ
from partition import partition
from MoJoFM import MoJoFM
from F_measure import get_F_measure
import time
import xlrd
import xlutils.copy
np.set_printoptions(threshold=np.inf)

'''
编码方式：
    编码：     [1,1,1,1,2,2,2]
    数组下标：   0,1,2,3,4,5,6
    即表示点{0,1,2,3}在社区1，点{4,5,6}在社区2

基本的标签传播算法(LPA)思想：
让每个结点与它的大多数邻居在同一个社区中。
具体算法流程为：
初始化，每个结点携带一个唯一的标签；（将初始化改为了没有入度的结点带一个唯一的标签）
然后更新结点的标签，令其标签与它的大多数邻居的标签相同，若存在多个则随机选择。(将邻居改为了后继)
迭代直至每个结点的标签不再变化。

'''

def can_stop(G,popsize,dim,X):
    # 所有结点的标签都和它邻居中出现频率最大的标签一致时停止
    for i in range(popsize):
        for j in range(dim):
            label = X[i,j]
            if G.out_degree(j) != 0:
                max_labels = get_max_neighbor_label(G,X[i,:],j)
                if (label not in max_labels):
                    return False
    return True

def get_max_neighbor_label(G, X, node):
    m = collections.defaultdict(int)    #以键值对的方式计数
    neighbors = (list(G.predecessors(node))+list(G.successors(node)))
    for neighbor_index in neighbors:
        neighbor_label = X[neighbor_index]
        m[neighbor_label] += 1   #neighbor_label出现一次就加1
    max_v = max(m.values())
    # m.items() = ([(neigbor_lable1,出现次数),(neigbor_lable2,出现次数)...])
    return [item[0] for item in m.items() if item[1] == max_v] #如果有多个max_v就返回list


def populate_label(G,popsize,dim,X):
    # 访问随机长度的随机序列
    for i in range(popsize):
        visitSequence = random.sample(G.nodes, int(dim * random.random()))
        #print("visitSequence",visitSequence)
        for j in visitSequence:
            label = X[i,j]
            if G.out_degree(j) != 0:
                max_labels = get_max_neighbor_label(G,X[i,:],j)
            #所有邻居的标签出现次数都一样，则随机选取其中一个标签
                if (label not in max_labels):
                    newLabel = random.choice(max_labels)
                    X[i,j] = newLabel
    return X

def get_path_num(G):

    dim = len(G.nodes)
    path_num = np.zeros([dim, dim])
    for i in range(dim):
        for j in range(dim):
            if (i != j) and (nx.has_path(G, i, j)):
                path_num[i, j] = 1
            else:
                path_num[i, j] = 0

    return path_num

def get_path_length(G):

    dim = len(G.nodes)
    shortest_path_length = np.zeros([dim, dim])
    for i in range(dim):
        for j in range(i + 1, dim):
            if (nx.has_path(G, i, j)):
                shortest_path_length[i, j] = nx.shortest_path_length(G, i, j)

    return shortest_path_length

def com_unfroze(G):
    n = len(G.nodes)
    froze = []
    unfroze = []
    du = G.degree()

    for i in range(n):
        if G.out_degree(i) != 0:
            unfroze.append(i)#print("i",i,neibors)
        else:
            froze.append(i)
    return unfroze,froze

def init(G,unfroze):
    n = len(G.nodes)
    nodeSect = []

    ind = np.empty(n)
    ind.fill(np.inf)
    label = 0
    set3 = []
    for k in unfroze:
        neibor1 = (list(G.predecessors(k)) + list(G.successors(k)))
        if ind[k] == np.inf:
            for neibor in neibor1:
                neibor2 = (list(G.predecessors(neibor)) + list(G.successors(neibor)))
                set1 = list(set(neibor1).intersection(neibor2))
                if set1 != []:
                    set2 = set(set1).union([neibor])
                    set2 = set(set2).union([k])  # print("set2",set2) #print("n",nodeInsect)
                    if set2 not in nodeSect:
                        nodeSect.append(set2)
                        for j in set2:
                            ind[j] = label
                        label += 1

    len1 = len(nodeSect)#print("first label",label,newind )
    sect = []
    for i in range(len1):
        sect.append(list(nodeSect[i]))
    nodeSect = sect.copy()
    return nodeSect

def re_init(G,unfroze):
    nodeInsect = []
    label = 0
    n = len(G.nodes)

    oldind = np.empty(n)
    oldind.fill(np.inf)
    for k in unfroze:
        neibor1 = list(G.adj[k])
        if oldind[k] == np.inf:
            for nei1 in neibor1:
                neibor2 = list(G.adj[nei1])
                for nei2 in neibor2:
                    neibor3 = list(G.adj[nei2])
                    set1 = list(set(neibor1).intersection(neibor3))
                    if len(set1) > 2:
                        set2 = set(set1).union([nei2])
                        set2 = set(set2).union([k])  # print("set2",set2) #print("n",nodeInsect)
                        #print("indirect",set1,set2)
                        if set2 not in nodeInsect:
                            nodeInsect.append(set2)
                            #print("insert", set2)
                            #print("insert", nodeInsect)
                            for j in set2:
                                oldind[j] = label
                            label += 1
    sect = []
    len1 = len(nodeInsect)
    for i in range(len1):
        sect.append(list(nodeInsect[i]))
    nodeInsect = sect.copy()
    #print("nodeInsect",nodeInsect)

    return nodeInsect

def LPA(G,popsize,dim,max_iter):
    # 初始化标签，每个结点携带一个唯一的标签
    X = float("inf") * np.ones((popsize,dim))
    for i in range(popsize):
        for j in range(dim):
            X[i,j] = j
    #print("before X",X)
    #unfroze, froze = com_unfroze(G)
    #initial1 = init(G, unfroze)
    #initial2 = re_init(G, unfroze)
    #print("initial", initial)

    #for i in range(popsize):
    #    label = max(X[i])+1
    #    for j in initial2:
    #        for k in j:
    #            X[i, k] = label
    #        label += 1

    #for i in range(popsize):
    #    label = max(X[i])+1
    #    for j in initial2:
    #        for k in j:
    #            X[i, k] = label
    #        label += 1
    #print("after X", X)
    # 更新标签
    iter_time = 0
    while (not can_stop(G,popsize,dim,X) and iter_time < max_iter):
        X = populate_label(G,popsize,dim,X)
        #print("after X", X)
        iter_time += 1
    return X

if __name__ == '__main__':
    G = m2g.load_graph("NSGA2/dataset/Mozilla Firefox_matrix/accessible.txt")

    dim = len(G.nodes)
    popsize = 30
    Max_iter = 5
    B = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,2,2,0,6,2,2,2,2,2,2,2,2,2,2,2,6,6,2,2,2,3,2,2,2,2,2,2,0,6,6,6,2,2,1,6,2,2,2,2,2,2,2,2,1,6,0,2,2,2,2,4,4,4,4,0,6,4,4,4,4,4,4,4,4,0,6,4,4,0,0,4,4,0,6,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,1,2,2,6,6,1,2,2,0,6,2,2,2,2,0,0,7,7,7,7,7,7,8,8,8,8,8,8,8,8,8,8,0,6,8,8,0,6,8,8,8,8,8,8,8,8,8,8,0,6]

    #B = [0,0,1,1,2,3,1,4,4,4,4,4,4,5,5,6,6,4,4,4,4,4,4,6,6,3,4,4,4,4,4,4,4,4,7,7,4,4,4,4,4,4,6,6,6]


    MQ = []
    MoJo = []
    dist = []
    dist1 = []
    dist2 = []
    dist3 = []
    instab = []
    shortest_path_length = get_path_length(G)
    path_num = get_path_num(G)
    timerStart = time.time()
    X = LPA(G,popsize,dim,Max_iter)
    timerEnd = time.time()
    print("LPA time",timerEnd-timerStart)
    for i in range(popsize):
        X[i] = RRM(X[i])
    print(X)
    timerStart1 = time.time()
    for i in range(popsize):
        MQ.append(NewTurboMQ(X[i],partition(X[i]),G))
    timerEnd1 = time.time()
    print("MQ time1", timerEnd1 - timerStart1)
    print(MQ)
    print("mean", np.mean(MQ))
    print("median", np.median(MQ))
    print("best", max(MQ))
    print(X[np.argmax(MQ), :])
    print(MoJoFM(X[np.argmax(MQ), :], B))

    #timerStart2 = time.time()
    #for i in range(popsize):
    #    MoJo.append(MoJoFM(X[i], B))
    #timerEnd2 = time.time()
    #print("MoJo time2", timerEnd2 - timerStart2)
    #print(MoJo)
    #print("mean", np.mean(MoJo))
    #print("median", np.median(MoJo))
    #print("best", max(MoJo))
    #print(X[np.argmax(MoJo), :])

    #timerStart3 = time.time()
    #for i in range(popsize):
    #    dist.append(distMQ(X[i], shortest_path_length))
    #timerEnd3 = time.time()
    #print("dist time3", timerEnd3 - timerStart3)
    #print(dist)
    #print("mean", np.mean(dist))
    #print("median", np.median(dist))
    #print("best", max(dist))
    #print(X[np.argmax(dist), :])
    #print(MoJoFM(X[np.argmax(dist), :], B))

    #timerStart4 = time.time()
    #for i in range(popsize):
    #    dist1.append(distMQ1(X[i],G,shortest_path_length))
    #timerEnd4 = time.time()
    #print("dist1 time4", timerEnd4 - timerStart4)
    #print(dist1)
    #print("mean", np.mean(dist1))
    #print("median", np.median(dist1))
    #print("best", max(dist1))
    #print(X[np.argmax(dist1), :])
    #print(MoJoFM(X[np.argmax(dist1), :], B))

    #timerStart5 = time.time()
    #for i in range(popsize):
    #    dist3.append(distMQ3(X[i],G,shortest_path_length))
    #timerEnd5 = time.time()
    #print("dist3 time5", timerEnd5 - timerStart5)
    #print(dist3)
    #print("mean", np.mean(dist3))
    #print("median", np.median(dist3))
    #print("best", max(dist3))
    #print(X[np.argmax(dist3), :])
    #print(MoJoFM(X[np.argmax(dist3), :], B))

    #timerStart6 = time.time()
    #for i in range(popsize):
    #    instab.append(get_Instability(partition(X[i]), G))
    #timerEnd6 = time.time()
    #print("instab time6", timerEnd6 - timerStart6)
    #print(instab)
    #print("mean", np.mean(instab))
    #print("median", np.median(instab))
    #print("best", max(instab))
    #print(X[np.argmax(instab), :])
    #print(MoJoFM(X[np.argmax(instab), :], B))

