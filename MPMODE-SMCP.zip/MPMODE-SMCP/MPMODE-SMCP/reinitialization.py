import numpy as np
import random
import collections
from RRM import RRM
from TurboMQ import TurboMQ
from partition import partition
import matrix_to_graph as gh
np.set_printoptions(threshold=np.inf)
from random import choice

# 解码：把基于Locus-based表示法的个体转换成基于字符表示法的个体
# 思路：两个连接的节点（x,y）被赋予相同的标签
#编码方式：
 #   编码：     [1,1,1,1,2,2,2]
   # 数组下标：   0,1,2,3,4,5,6
  #  即表示点{0,1,2,3}在社区1，点{4,5,6}在社区2

#DLPA的处理过程与LPA相同，只是标签选择规则不同。
#结点i的标签选择规则：FCA
def can_stop(G,i1,i2,dim,X):
    # 所有结点的标签都和它邻居中出现频率最大的标签一致时停止
    for i in range(i1,i2):
        for j in range(dim):
            label = X[i, j]
        for j in range(dim):
            if G.out_degree(j) != 0:
                max_labels = get_max_successors_label(G, X[i, :], j)
                if (label not in max_labels):
                    return False
    return True

def get_max_successors_label(G, X, node):
    m = collections.defaultdict(int)    #以键值对的方式计数
    #print('first', node, G.neighbors(node))
    for neighbor_index in G.neighbors(node):
        neighbor_label = X[neighbor_index]
        m[neighbor_label] += 1   #neighbor_label出现一次就加1
        #print('label', m[neighbor_label],neighbor_label)
    max_v = max(m.values())
    #for neighbor_index in G.neighbors(node):

    # m.items() = ([(neigbor_lable1,出现次数),(neigbor_lable2,出现次数)...])
    return [item[0] for item in m.items() if item[1] == max_v] #如果有多个max_v就返回list

def get_max_weight_node(G):
    n = len(G.nodes)
    nod = []
    sumDegree = np.zeros([n])
    weight = np.zeros([n])
    froze = []
    unfroze = []
    du = G.degree()

    for i in range(n):
        if G.out_degree(i) != 0:
            unfroze.append(i)  # print("i",i,neibors)
        else:
            froze.append(i)
    for i in G.nodes:
        nod.append(i)
        neibors = list(G.adj[i])  # 找到i的所有邻居
        sumDegree[i] = 0
        if G.out_degree(i) != 0:
            for neibor in neibors:
                sumDegree[i] = sumDegree[i] + du(neibor)

    for i in G.nodes:
        neibors = list(G.adj[i])  # 找到i的所有邻居
        k1 = 0      #print("k1,", neibors, i)
        if G.out_degree(i) != 0:
            for neibor in neibors:
                k1 += sumDegree[neibor]
                #print("k1,",neibors,i)
            if k1 != 0:
                weight[i] = sumDegree[i] / k1

    index1 = np.argsort(weight, axis=0)[::-1]
    return index1

def populate_label(G, i, X):
    dim = len(G.nodes)
    visitSequence = random.sample(G.nodes, int(dim * random.random()))
    # if i==0:
    # print('orginal lable',visitSequence)
    for j in visitSequence:
        label = X[i, j]
        if G.out_degree(j) != 0:
            max_labels = get_max_successors_label(G, X[i, :], j)
            # 所有邻居的标签出现次数都一样，则随机选取其中一个标签
            if (label not in max_labels):
                newLabel = random.choice(max_labels)
                X[i, j] = newLabel

    return X

def populate_index_label(G, i, X):
    dim = len(G.nodes)
    visitSequence = get_max_weight_node(G)
    visitSequence = random.sample(G.nodes, int(dim * random.random()))
    # if i==0:
    # print('orginal lable',visitSequence)
    for j in visitSequence:
        label = X[i, j]
        if G.out_degree(j) != 0:
            max_labels = get_max_successors_label(G, X[i, :], j)
            # 所有邻居的标签出现次数都一样，则随机选取其中一个标签
            if (label not in max_labels):
                newLabel = random.choice(max_labels)
                X[i, j] = newLabel

    return X


def com_unfroze(G):
    n = len(G.nodes)
    froze = []
    unfroze = []
    du = G.degree()

    for i in range(n):
        if G.out_degree(i) != 0:
            unfroze.append(i)#print("i",i,neibors)
        else:
            froze.append(i)
    return unfroze,froze

def init(G,unfroze):
    n = len(G.nodes)
    nodeSect = []

    ind = np.empty(n)
    ind.fill(np.inf)
    label = 0
    set3 = []
    for k in unfroze:
        neibor1 = list(G.adj[k])
        if ind[k] == np.inf:
            for neibor in neibor1:
                neibor2 = list(G.adj[neibor])
                set1 = list(set(neibor1).intersection(neibor2))
                if set1 != []:
                    set2 = set(set1).union([neibor])
                    set2 = set(set2).union([k])  # print("set2",set2) #print("n",nodeInsect)
                    if set2 not in nodeSect:
                        nodeSect.append(set2)
                        for j in set2:
                            ind[j] = label
                        label += 1
    len1 = len(nodeSect)#print("first label",label,newind )
    sect = []
    for i in range(len1):
        sect.append(list(nodeSect[i]))
    nodeSect = sect.copy()
    #print("nodesect initial",nodeSect)
    return nodeSect

def re_init(G,unfroze):
    nodeInsect = []
    label = 0
    n = len(G.nodes)

    oldind = np.empty(n)
    oldind.fill(np.inf)
    for k in unfroze:
        neibor1 = list(G.adj[k])
        if oldind[k] == np.inf:
            for nei1 in neibor1:
                neibor2 = list(G.adj[nei1])
                for nei2 in neibor2:
                    neibor3 = list(G.adj[nei2])
                    set1 = list(set(neibor1).intersection(neibor3))
                    if len(set1) > 2:
                        set2 = set(set1).union([nei2])
                        set2 = set(set2).union([k])  # print("set2",set2) #print("n",nodeInsect)
                        #print("indirect",set1,set2)
                        if set2 not in nodeInsect:
                            nodeInsect.append(set2)
                            #print("insert", set2)
                            #print("insert", nodeInsect)
                            for j in set2:
                                oldind[j] = label
                            label += 1
    sect = []
    len1 = len(nodeInsect)
    for i in range(len1):
        sect.append(list(nodeInsect[i]))
    nodeInsect = sect.copy()
    #print("nodeInsect",nodeInsect)

    return nodeInsect

def LPA_NEW(G,popsize,max_iter):
    # 初始化标签，每个结点携带一个唯一的标签
    n = len(G.nodes)
    dim =n
    du = G.degree
    unfroze,froze = com_unfroze(G)

    X = float("inf") * np.ones((popsize,dim))
    for i in range(popsize):
        for j in range(dim):
            X[i,j] = j
    # 更新标签
    miter = popsize//4
    iter_time = 0
    while (not can_stop(G,iter_time,miter,dim,X) and iter_time <max_iter):
        for ii in range(miter):
            populate_label(G,ii,X)
        iter_time += 1

    miter = max_iter // 2
    while (not can_stop(G,iter_time,miter,dim,X) and iter_time < max_iter):
        for ii in range(miter):
            populate_index_label(G, ii, X)
        iter_time += 1

    initial1 = init(G, unfroze)
    print("initial1",initial1)
    print(len(initial1))
    label = n
    kk = len(initial1)
    for ii in range(kk):
        for j in initial1[ii]:
            X[iter_time, j] = label
        label += 1
    cur = iter_time
    miter = max_iter*3 // 4
    while (not can_stop(G,iter_time,miter,dim, X) and iter_time < max_iter):
        for j in range(dim):
            X[iter_time, j] = X[cur, j]
        for ii in range(miter):
            populate_index_label(G, ii, X)
        iter_time += 1

    initial2 = re_init(G, unfroze)
    print("initial2", initial2)
    print(len(initial2))
    label = n
    kk = len(initial2)
    for ii in range(kk):
        for j in initial2[ii]:
            X[iter_time, j] = label
        label += 1
    cur = iter_time
    miter = popsize
    while (not can_stop(G,iter_time,miter,dim,X) and iter_time < max_iter):
        for j in range(dim):
            X[iter_time, j] = X[cur, j]
        for ii in range(miter):
            populate_index_label(G, ii, X)
        iter_time += 1

    return X, unfroze,froze


if __name__ == '__main__':

    if __name__ == '__main__':

        G = gh.load_graph("NSGA2/dataset/Mozilla Firefox_matrix/ipc.txt")
        max_iter = 20
        popsize = 50
        print(len(G.nodes))
        X, a, b = LPA_NEW(G, popsize, max_iter)
        MQ = []
        #for i in range(popsize):
        #    print(i, X[i])
        print("leve1")
        for i in range(popsize // 3):
            cs = RRM(X[i, :])
            print(TurboMQ(partition(cs), G))
            MQ.append(TurboMQ(partition(cs), G))
        print("leve2")
        for i in range(popsize // 3, popsize * 2 // 3):
            cs = RRM(X[i, :])
            print(TurboMQ(partition(cs), G))
            MQ.append(TurboMQ(partition(cs), G))
        print("leve3")
        for i in range(popsize * 2 // 3, popsize):
            cs = RRM(X[i, :])
            print(TurboMQ(partition(cs), G))
            MQ.append(TurboMQ(partition(cs), G))
        #print(max(MQ))
        #print(np.argmax(MQ))


    #X = float("inf") * np.ones(len(G.nodes))
    #for i in range(len(G.nodes)):
    #    X[i] = i
    #print(X)
    #x = get_max_weight_node(G, X, 5)
    #print(x)
