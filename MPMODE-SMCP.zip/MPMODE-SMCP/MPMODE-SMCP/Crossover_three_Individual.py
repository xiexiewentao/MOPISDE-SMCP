import numpy as np
import random
import Graphhelper as gh
from Initial_with_MLPA import LPA
from TurboMQ import TurboMQ
#from RRM import RRM
from RRM import indiRRM
from MS import MS
#from C2C import C2CCalculation
#from RouletteWheelSelection import pairSelection
from partition import partition

'''
交叉方法：
轮盘赌策略选择两个父代：
parent1:    [4,3,2,2,6,5,6]
parent2:    [3,3,1,5,4,7,6]
选择一个断点，比如3
offspring1: [4,3,2,\/ 5,4,7,6]  
offspring2: [4,3,1,/\ 2,6,5,6] 
从结点3的位置断开，后半部分进行交换 

'''

def crossover1(parent1, parent2, parent3,crossoverProbability):

    offspring1 = parent1.copy()
    parentsCrossoverProbability = random.uniform(0.0, 1.0)
    if parentsCrossoverProbability < crossoverProbability:
        offspring1 = cross(offspring1, parent2, parent3)
    else:
        offspring1 = crossClass(offspring1, parent2,parent3)
    offspring1 = indiRRM(offspring1)

    return offspring1

def crossover(X, i,pop,t,MaxIter,dim):

    newind = X[i].copy()
    oldind = X[i].copy()
    maxLabel = max(newind)
    for ini in range(2):
        kk = (MaxIter - t) // 10 + 2
        indi = random.randint(0, pop // kk)
        if (t > MaxIter // 3 and ini == 1) or (t > MaxIter * 2 // 3):
            indi = random.randint(pop // kk, pop - 1)
        replace_nodes = random.sample(range(0, dim), round(1))
        for node in replace_nodes:  # 对第i个节点及其邻居执行joint-gene变异
            for k in range(dim):
                if X[indi, k] == X[indi, node]:  # 赋予一个新标签
                    newind[k] = maxLabel + 1
        maxLabel = maxLabel + 1
        newind = indiRRM(newind)

    return oldind



def crossfreq(X, i,freq):
    ind = X[i].copy()
    maxLabel = max(ind)
    dim1 = len(freq)

    parentsCrossoverProbability = random.uniform(0.0, 1.0)
    if parentsCrossoverProbability < 0:
        if dim1 > 1:
            indi = random.randint(0, dim1-1)
            repla = random.sample(range(0, dim1), 1)
        else:
            repla = [0]
        for kk in repla:
            for k in freq[kk]:  # 对第i个节点及其邻居执行joint-gene变异
                ind[k] = maxLabel + 1
            maxLabel = maxLabel + 1
    else:
        for cf in freq:
            for k in cf:
                ind[k] = maxLabel + 1
            maxLabel = maxLabel + 1

    ind = indiRRM(ind)

    return ind


def crossfreq1(X, i, G,freq, rest):
    ind = X[i].copy()
    maxLabel = max(ind)
    dim1 = len(freq)
    dim2 = len(rest)

    #把commset变为一类
    for cf in freq:
        for k in cf:
            ind[k] = maxLabel + 1
        maxLabel = maxLabel + 1

    #rest随机变
    if rest != []:
        nodes = random.sample(rest, random.randint(0, dim2 - 1))
        for j in nodes:
            neighbors = (list(G.predecessors(j))+list(G.successors(j)))
            if len(neighbors) != 0:
                repla = random.sample(neighbors, 1)
                for k in repla:
                    if ind[j] != ind[k]:
                        ind[j] = ind[k]

    ind = indiRRM(ind)

    return ind


def  cross(offspring1, parent2, parent3):
    # 三个父代之间发生交叉的点
    dim = len(offspring1)
    cross1 = random.randint(0,dim//3)
    cross2 = random.randint(dim//3,2*dim//3)
    #print("cross",dim,dim//3, cross1, cross2)
    # 子代的基因保留一部分，一部分取自父代1，而另一部分取自父代2
    offspring1 = np.concatenate([offspring1[0:cross1], parent2[cross1:cross2],parent3[cross2:]])
    # 子代的基因上半部分取自父代2，而其后半部分取自父代1

    return offspring1

def crossClass(offspring1, parent2,parent3):

    # 三个父代之间按类进行交叉
    dim = len(offspring1)
    X1 = []
    X2 = []
    offspring1 = offspring1.copy()
    #offspring2 = parent2.copy()

    for i in range(dim):
        if offspring1[i] != parent2[i]:
            X1.append(int(i))
        if offspring1[i] != parent3[i]:
            X2.append(int(i))
    if X1 == []:
        k1 = random.sample(range(0,dim), 1)
    else :
        k1 = random.sample(X1, 1)
    label1 = (int)(offspring1[k1[0]])
    label2 = (int) (parent2[k1[0]])
    #print("i", k1 , label1,label2)
    for i in range(dim):
        j = (int)(offspring1[i])
        if j == label1:
            offspring1[i] = label2
    #print("cross",k1,label1, label2)
    if X2 == []:
        k1 = random.sample(range(0,dim), 1)
    else:
        k1 = random.sample(X2, 1)
    label1 = (int)(offspring1[k1[0]])
    label2 = (int)(parent3[k1[0]])
    for i in range(dim):
        j = (int)(offspring1[i])
        if j == label1:
            offspring1[i] = label2

    return offspring1


if __name__ == '__main__':

    G = gh.load_graph("NSGA2/dataset/rcs.txt")
    dim = len(G.nodes)
    popsize = 3
    X = np.ones(popsize) * float("inf")
    scores = np.ones(popsize)
    ms = np.ones(popsize)
    reverse = np.ones(popsize)
    direction = np.ones(popsize)
    multi_class = np.zeros((2*popsize,dim), np.float32)
    cluster_num = np.ones(popsize)
    count = 0
    crossoverProbability = 0
    X1 = [0,1,0,0,1,0,1,1,2,1,2,3,0,0,3,0,3,3,3,3]
    MQ1 = TurboMQ(partition(X1),G)
    print(MQ1)

    X2 = [0,1,0,0,1,0,1,1,2,1,3,4,4,0,4,0,4,4,4,4]
    print(TurboMQ(partition(X2), G))
    X3 = [0,0,1,2,3,3,3,1,4,3,1,5,5,2,5,5,5,5,5,5]
    print(TurboMQ(partition(X3), G))

    print(TurboMQ(partition(X), G))
    for i in range(100):
        X = crossover1(X1, X2, X3, crossoverProbability)
        MQ = TurboMQ(partition(X), G)
        if MQ >MQ1:
            count += 1
            print(MQ)
    print(count)

