import random
from Initial_with_best_neighbor import initialization
import Graphhelper as gh
import numpy as np
from TurboMQ_encode import TurboMQ
from Decode import decode

'''

轮盘赌策略

'''

def pairSelection(population, fitness, popsize):

    parent1Id = rouletteWheelSelectionId(fitness, popsize)
    parent1 = population[parent1Id].copy()

    parent2Id = rouletteWheelSelectionId(fitness, popsize)
    parent2 = population[parent2Id].copy()

    return parent1, parent2


def rouletteWheelSelectionId(fitness, popsize):

    #先将fitness值倒置再进行选择，即fitness值越小越容易被选中来进行交叉策略
    reverse = max(fitness) + min(fitness)
    reverseScores = reverse - fitness
    sumScores = sum(reverseScores)
    pick = random.uniform(0, sumScores)
    current = 0
    for individualId in range(popsize):
        current += reverseScores[individualId]
        if current > pick:
            return individualId


if __name__ == '__main__':

    G = gh.load_graph("NSGA2/dataset/rcs.txt")
    popsize = 5
    fitness = np.ones(popsize) * float("inf")
    X = initialization(popsize, len(G.nodes), G)
    cluster = []
    for i in range(popsize):
        cluster.append(decode(X[i, :]))
        fitness[i] = TurboMQ(cluster[i], G)
    parents2, parents3 = pairSelection(X, fitness, popsize)
    print(parents2)
    print(parents3)
