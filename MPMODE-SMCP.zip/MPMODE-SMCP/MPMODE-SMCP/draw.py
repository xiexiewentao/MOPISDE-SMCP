import numpy as np
import matplotlib.pyplot as plt

size = 10
x = np.arange(0,20,2)
#best mojo
#a = [47.05,65,21.05,57.48,90.42,51.26,58.68,39.91,61.48,10.59]
#b = [49.41,82.6,21.05,45.96,98.93,68.98,89.82,60.98,76.67,13.69]
#c = [49.41,72.5,57.89,26.61,91.48,68.98,82.63,63.22,85.33,11.11]
#avg mojo
a = [44.47,62.25,21.05,55.67,79.84,49.17,57.26,36.53,60.64,9.09]
b = [33.37,75.08,21.05,24.92,97.65,56.3,89.22,56.86,69.54,13.48]
c = [37.82,50.75,33.15,21.18,88.22,46.45,47.39,62.06,76.22,7.23]
#d = [42.05,56,26.05,58.48,89.42,52.26,51.68,52.91,63.48,11.59]
#best pre
#a = [40.58,8.78,100,2.93,99.67,90.68,100,51.65,99.48,93.02]
#b = [41.92,99.72,100,22.23,99.96,82.9,100,46.41,93.57,99.63]
#c = [61.31,76.14,8.33,13.8,91.56,64.77,100,98.72,98.41,100]
#d = [61.31,76.14,8.33,13.8,91.56,64.77,100,98.72,98.41,100]


total_width, n = 1.2, 3
width = total_width / n
x = x - (total_width - width) /2
d = plt.bar(x, a, width=width, label='TurboMQ', color="#fb9a89")
e = plt.bar(x + width, b, width=width, label='Global Stability', color="#6399bf")
f = plt.bar(x + 2 * width, c, width=width, label='Execution Path Complexity', color="#ffd38a")

def autolabel(rects):
 for rect in rects:
  height = rect.get_height()-1
  plt.text(rect.get_x()+rect.get_width()/2.-0.2, 1.03*height, '%s%%' % round(rect.get_height()))

def autolabel1(rects):
 for rect in rects:
  height = rect.get_height()-1
  plt.text(rect.get_x() + rect.get_width() / 2. - 0.2, 1.03 * height, '%s%%' % round(rect.get_height()))

def autolabel2(rects):
 for rect in rects:
  height = rect.get_height()-6
  plt.text(rect.get_x() + rect.get_width() / 2. - 0.2, 1.03 * height, '%s%%' % round(rect.get_height()))


autolabel2(d)
autolabel(e)
autolabel1(f)

plt.xlim(-2,20)
plt.xticks([0,2,4,6,8,10,12,14,16,18],['Accessible', 'Browser', 'Build', 'Content', 'Db','Dom', 'Extensions', 'Gfx', 'Intl', 'Ipc'])
plt.xlabel('Data set')
plt.ylabel('The Average value of MoJoFM')
#plt.ylabel('The Best value of MoJoFM')

plt.legend()
plt.show()
