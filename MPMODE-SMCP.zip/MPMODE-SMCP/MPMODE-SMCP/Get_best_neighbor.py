import Graphhelper as gh

'''
    找出与node相连节点中与node的相连节点相同节点数最多的点是最好邻居
'''

def get_best_neighbor(node,G):
    maxshared = -1
    best_neighbor = float("inf")
    for i in G.successors(node):
        shared = len((set(G.successors(i))) & (set(G.successors(node))))
        if (shared > maxshared):
            maxshared = shared
            best_neighbor = i
    return best_neighbor


if __name__ == "__main__":
    G = gh.load_graph("NSGA2/dataset/rcs.txt")
    pos = get_best_neighbor(1,G)
    print(pos)
    
