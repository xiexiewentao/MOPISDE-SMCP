import networkx as nx
import numpy as np
import matrix_to_graph as m2g
import Graphhelper as gh
from partition import partition
from RRM import RRM
from copy import deepcopy
np.set_printoptions(threshold=np.inf)


def get_path_length(G):
    dim = len(G.nodes)
    shortest_path_length = np.zeros([dim, dim])
    for i in range(dim):
        for j in range(dim):
            if (i != j) and (nx.has_path(G, i, j)):
                shortest_path_length[i, j] = nx.shortest_path_length(G, i, j)
            else:
                shortest_path_length[i, j] = 0

    return shortest_path_length

def get_path_num(G):

    dim = len(G.nodes)
    path_num = np.zeros([dim, dim])
    for i in range(dim):
        for j in range(dim):
            if (i != j) and (nx.has_path(G, i, j)):
                path_num[i, j] = 1
            else:
                path_num[i, j] = 0

    return path_num

#X为patition(X)
def M1(X,G):

    graph = G.to_undirected()
    s = []

    dim = len(G.nodes)
    for clus1 in X:
        for i in clus1:
            a = 0
            if len(clus1) == 1:
                a = 0
            else:
                for j in clus1:
                    if i != j:
                        if (nx.has_path(graph,i,j)):
                            a += (nx.shortest_path_length(graph,i,j))
                a = a / (len(clus1)-1)
            temp = []
            for clus2 in X:
                d = 0
                if clus1 != clus2:
                    for j in clus2:
                        if (nx.has_path(graph,i,j)):
                            d += (nx.shortest_path_length(graph,i,j))
                if d != 0:
                    temp.append(d / len(clus2))
            if temp != []:
                b = min(temp)
            else:
                b=0
            s.append((b-a)/max(b,a))

    return sum(s)/dim

def M2(X,G):

    graph = G.to_undirected()
    clus = partition(X)
    clus_num = len(clus)
    intra_dist = 0
    intra_count = 0
    inter_dist = 0
    inter_count = 0
    for i in range(clus_num):
        for j in range(len(clus[i])):
            for k in range(j+1,len(clus[i])):
                if (nx.has_path(graph, clus[i][j], clus[i][k])):
                    intra_dist += nx.shortest_path_length(graph,clus[i][j], clus[i][k])
                    intra_count += 1
    intra_dist = intra_dist/intra_count

    for i in range(clus_num):
        for j in range(i+1,clus_num):
            for ii in clus[i]:
                for jj in clus[j]:
                    if (nx.has_path(graph, ii, jj)):
                        inter_dist += nx.shortest_path_length(graph, ii, jj)
                        inter_count += 1
    inter_dist = inter_dist / inter_count

    M2 = inter_dist - intra_dist

    return M2

def M3(X,G):

    #graph = G.to_undirected()
    clus = partition(X)
    clus_num = len(clus)

    inter_dist = 0
    inter_count = 0
    for i in range(clus_num):
        intra_dist = 0
        intra_count = 0
        for j in range(len(clus[i])):
            for k in range(j+1,len(clus[i])):
                if (nx.has_path(G, clus[i][j], clus[i][k])):
                    intra_dist += nx.shortest_path_length(G,clus[i][j], clus[i][k])
                    intra_count += 1
        if intra_count != 0 :
            intra_dist += intra_dist/intra_count
    intra_dist = intra_dist/clus_num

    for i in range(clus_num):
        for j in range(i+1,clus_num):
            for ii in clus[i]:
                for jj in clus[j]:
                    if (nx.has_path(G, ii, jj)):
                        inter_dist += nx.shortest_path_length(G, ii, jj)
                        inter_count += 1
    if inter_count != 0:
        inter_dist = inter_dist / inter_count
        inter_dist = inter_dist / (clus_num * (clus_num -1)/2)

    M3 = inter_dist - intra_dist

    return M3

#从M3扩展出distMQ,原始distMQ,计算考虑的是最短路径长度，与M3的区别在于考虑了方向
def distMQ(X,shortest_path_length):

    clus = partition(X)
    clus_num = len(clus)
    clus_intra_dist = []
    clus_inter_dist = []

    for i in clus:
        intra_dist = 0
        intra_count = 0
        for j in i:
            for k in i:
                intra_dist += shortest_path_length[j,k]
                if shortest_path_length[j,k] != 0:
                    intra_count += 1
        if intra_count != 0 :
            clus_intra_dist.append(intra_dist/intra_count)
    int = sum(clus_intra_dist)/clus_num

    for i in range(clus_num):
        inter_dist = 0
        inter_count = 0
        for j in range(i+1,clus_num):
            for ii in clus[i]:
                for jj in clus[j]:
                    inter_dist += shortest_path_length[ii,jj]
                    if shortest_path_length[ii,jj] != 0:
                        inter_count += 1
        if inter_count != 0 :
            clus_inter_dist.append(inter_dist/inter_count)
    if clus_num != 1:
        bet = sum(clus_inter_dist)/((clus_num * (clus_num -1)/2))
    else:
        bet = 0

    distMQ = bet - int

    return distMQ

#只考虑无入度的结点的distMQ，计算考虑的是最短路径长度
def distMQ1(X,G,shortest_path_length):
    clus = partition(X)
    clus_num = len(clus)
    clus_intra_dist = []
    clus_inter_dist = []

    for i in clus:
        intra_dist = 0
        intra_count = 0
        for j in i:
            for k in i:
                if list(G.predecessors(j)) == []:
                    intra_dist += shortest_path_length[j, k]
                    if shortest_path_length[j, k] != 0:
                        intra_count += 1
        if intra_count != 0:
            clus_intra_dist.append(intra_dist / intra_count)
    int = sum(clus_intra_dist) / clus_num

    for i in range(clus_num):
        inter_dist = 0
        inter_count = 0
        for j in range(i + 1, clus_num):
            for ii in clus[i]:
                for jj in clus[j]:
                    if list(G.predecessors(ii)) == []:
                        inter_dist += shortest_path_length[ii, jj]
                        if shortest_path_length[ii, jj] != 0:
                            inter_count += 1
        if inter_count != 0:
            clus_inter_dist.append(inter_dist / inter_count)
    if clus_num != 1:
        bet = sum(clus_inter_dist) / ((clus_num * (clus_num - 1) / 2))
    else:
        bet = 0

    #distMQ1 = bet - int
    if bet == 0 and int == 0 :
        distMQ1 = 0
    else:
        distMQ1 = bet / (bet + int)

    return distMQ1

#只考虑无入度的结点的distMQ，模块内路径数-模块外路径数，数值越大越好
def distMQ2(X,G,path_num):

    clus = partition(X)
    clus_num = len(clus)
    intra_path = 0
    inter_path = 0

    for i in clus:
        for j in i:
            for k in i:
                if list(G.predecessors(j)) == []:
                    if (k != j) and (path_num[j, k] == 1):
                        intra_path += 1
    intra_path_num = intra_path / clus_num

    for i in range(clus_num):
        for j in range(i + 1, clus_num):
            for ii in clus[i]:
                for jj in clus[j]:
                    if (ii != jj) and (list(G.predecessors(ii)) == []):
                        if path_num[ii, jj] == 1:
                            inter_path += 1
    if clus_num != 1:
        inter_path_num = inter_path / (clus_num * (clus_num - 1) / 2)
    else:
        inter_path_num = 0

    distMQ2 = intra_path_num - inter_path_num

    return distMQ2

#考虑无入度的结点到无出度结点的distMQ，计算考虑的是最短路径长度
def distMQ3(X,G,shortest_path_length):
    clus = partition(X)
    clus_num = len(clus)
    clus_intra_dist = []
    clus_inter_dist = []

    for i in clus:
        intra_dist = 0
        intra_count = 0
        for j in i:
            for k in i:
                if list(G.predecessors(j)) == [] and list(G.successors(k)) == []:
                    intra_dist += shortest_path_length[j, k]
                    if shortest_path_length[j, k] != 0:
                        intra_count += 1
        if intra_count != 0:
            clus_intra_dist.append(intra_dist / intra_count)
    int = sum(clus_intra_dist) / clus_num

    for i in range(clus_num):
        inter_dist = 0
        inter_count = 0
        for j in range(i + 1, clus_num):
            for ii in clus[i]:
                for jj in clus[j]:
                    if list(G.predecessors(ii)) == [] and list(G.successors(jj)) == []:
                        #print(ii,jj)有问题
                        inter_dist += shortest_path_length[ii, jj]
                        if shortest_path_length[ii, jj] != 0:
                            inter_count += 1
        if inter_count != 0:
            clus_inter_dist.append(inter_dist / inter_count)
    if clus_num != 1:
        bet = sum(clus_inter_dist) / ((clus_num * (clus_num - 1) / 2))
    else:
        bet = 0

    #print("int",int)
    #print("bet",bet)
    #distMQ1 = bet - int
    if bet == 0 and int == 0 :
        distMQ3 = 0
    else:
        distMQ3 = int / (bet + int)

    return distMQ3

#Function to find index of list
def index_of(a,list):
    index = []
    for i in range(0,len(list)):
        if list[i] == a:
            index.append(i)
    if len(index) != 0:
            return index
    else:
        return False

#G.has_edge是考虑方向的
def get_Intra_edge_num(cluster,G):
    #intra_node_num = 0
    intra_edge_num = 0
    for i in cluster:
        #intra_node_num += 1
        for j in cluster:
            if G.has_edge(int(i),int(j)):
                intra_edge_num += 1
                #print("x",i,X[i],j,X[j])

    #cluster_A = intra_node_num/(intra_edge_num*intra_edge_num)

    return intra_edge_num

#只考虑不在同一社区的边数
def get_Inter_edge_num(cluster,G, mutated):

    inter_edge_num = 0
    for i in cluster:
        for j in G.nodes:
            if j not in cluster:
                if (G.has_edge(i,j) | G.has_edge(j,i)):
                    inter_edge_num += 1
                    if i not in mutated:
                        mutated.append(i)
                    if j not in mutated:
                        mutated.append(j)


    return inter_edge_num



def MFcalculation(cluster,G,mutated):
    #nodes_num = len(cluster)
    i = get_Intra_edge_num(cluster,G)
    j = get_Inter_edge_num(cluster,G,mutated)

    if i == 0:
        MF = 0
    else:
        MF = i / (i + j/2)
    #print("ik",i,j)

    return MF

def get_sum_of_inter_edge(X,G):

    cluster_num = len(X)
    inter = []
    mutated = []

    for i in range(cluster_num):
        clus = X[i]
        inter.append(get_Inter_edge_num(clus, G, mutated))

    return -sum(inter)


def get_sum_of_intra_edge(X, G):
    cluster_num = len(X)
    intra = []

    for i in range(cluster_num):
        clus = X[i]
        intra.append(get_Intra_edge_num(clus,G))

    return sum(intra)

def get_independence_num(X):
    cluster_num = len(X)
    inden = 0

    for i in range(cluster_num):
        clus = X[i]
        if len(clus) == 1:
            inden += 1

    return -inden

#按边进行计算所有节点的MQ
def NewTurboMQ(X,XX,G):

    n = len(G.nodes)
    cluster_num = len(XX)
    #numClus为每个社区的长度
    numClus = np.zeros([cluster_num])
    mutated = []
    nodeClus = np.zeros([n,cluster_num])
    interNei = np.zeros([cluster_num])
    intraNei = np.zeros([cluster_num])

    MQ = 0
    for c in G.edges:
        #获取边结点
        c0 = c[0]
        c1 = c[1]
        #获取边结点所在社区标签
        x0 = int(X[c0])
        x1 = int(X[c1])

        if x0 != x1:
            interNei[x0] += 1
            interNei[x1] += 1
        else:
            intraNei[x0] += 1#同一社区间的边
        #遍历标记,nodeClus记录每个结点有多少条边,以及该结点属于哪一个社区
        nodeClus[c0, x0] += 1
        nodeClus[c1, x1] += 1
    for i in range(cluster_num):
        numClus[i] = len(XX[i])
        if (intraNei[i] == 0) and (interNei[i] == 0):
            MQ += 0
        else:
            MQ += (intraNei[i]/(intraNei[i] + interNei[i]/2))

    #print("nodeClus",nodeClus)
    #for i in range(n):
    #    mu = []
    #    xi = int(X[i])
        #min为结点i的边数
    #    min = nodeClus[i, xi]
        #此处的nei指的是i的后继
    #    for nei in G.adj[i]:
    #        j = int(X[nei])
            #if nodeClus[i,j] > min不合理呀？？？不可能有nodeClus[i,j] > min的情况
            #nodeClus只记录每个结点有多少条边,以及该结点属于哪一个社区
            #nodeClus是一个每行只有一列有数值，其余列值为0的数组
            #nodeClus[i,j] > 0这个条件也不合理？？？
    #        if (nodeClus[i,j] > min) | ((numClus[xi] > numClus[j]) & (nodeClus[i,j] > 0)) :
    #            mu.append(j)
    #    if mu != []:
    #        mutated.append(mu)

    return MQ

#此处参数X为partition(X)
def TurboMQ(X,G):

    cluster_num = len(X)
    MF = []
    mutated = []

    for i in range(cluster_num):
        clus = X[i]
        MF_value = MFcalculation(clus,G,mutated)
        MF.append(MF_value)

    #print("max", max, "min",min, "totalnumber",cluster_num,"reverse", reverse, "direction",direction)

    MQ = sum(MF)

    #return MQ,reverse,direction,cluster_num,mutation_nodes
    return MQ

if __name__ == '__main__':

    G = m2g.load_graph("NSGA2/dataset/Mozilla Firefox_matrix/accessible.txt")
    #G = gh.load_graph("dataset/test.txt")
    #X = [0,0,1,0,1,1,1,1]
    #Y = [0,0,0,0,1,1,1,1]
    dim = len(G.nodes)
    tmp = []
    shortest_path_length = get_path_length(G)
    print(shortest_path_length)
    for i in range(dim):
        for j in range(dim):
            if list(G.predecessors(i)) == [] and list(G.successors(j)) == []:
                if shortest_path_length[i,j] != 0:
                    tmp.append(shortest_path_length[i,j])
                    print("node",i,"-->",j,"EPL",shortest_path_length[i,j])
    #print(distMQ3(X,G,shortest_path_length))
    #print(distMQ3(Y,G,shortest_path_length))
    #X = [0,0,0,1,1,2,1,0,1,1,1,1,1,2,2,2,2,2,2,2]
    #X = [0,1,1,0,0,2,2,2]
    #X = [0,0,1,1]
    #Y = [0,0,0,1]
    #path_length = get_path_length(G)
    #print(path_length)
    #print(distMQ(X, path_length))
    #print(distMQ(Y, path_length))
    #Y = [0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0]
    #X = [0,1,0,2,1,2,1,0,3,1,3,3,3,2,2,2,4,4,4,4]
    #X1 = [0,1,0,2,1,2,1,1,3,1,3,3,3,2,2,2,4,4,4,4]
    #X2 = [0,1,0,2,1,2,1,1,3,1,0,3,3,2,2,2,4,4,4,4]
    #X3 = [0,1,0,2,1,2,1,0,3,1,3,3,3,2,4,2,4,4,4,4]
    #X4 = [0,1,0,2,1,3,1,1,4,1,4,4,4,2,5,3,5,5,5,5]
    #X5 = [0,1,0,2,1,2,1,1,3,1,3,3,3,2,4,2,4,4,4,4]
    #X6 = [0,1,0,2,1,3,1,1,4,1,0,4,4,2,5,3,5,5,5,5]
    #X7 = [0,1,0,2,1,2,1,1,3,1,0,3,3,2,4,2,4,4,4,4]
    #X8 = [0,1,0,2,1,3,1,1,4,1,4,4,4,3,2,3,5,5,5,5]
    #X9 = [0,1,0,2,3,4,3,1,5,3,5,6,6,2,7,4,7,7,7,7]
    #X = [0,1,0,0,1,2,1,1,3,1,3,3,3,2,4,2,4,4,4,4]
    #Y = RRM(Y)
    #MQ1 = TurboMQ(partition(Y),G)
    #print("mq", MQ1)
    #MQ2, mutated = NewTurboMQ(X, partition(X), G)
    #print("mq",MQ2)
    #print("mu",mutated)
    #print(get_sum_of_inter_edge(partition(X),G))
    #print(get_sum_of_intra_edge(partition(X),G))
    #print(get_independence_num(partition(X)))
    #print(TurboMQ(partition(X), G))
    #print(distMQ(X, G))
    #print(distMQ(X1, G))
    #print(TurboMQ(partition(X2), G))
    #print(TurboMQ(partition(X3), G))
    #print(TurboMQ(partition(X4), G))
    #print(TurboMQ(partition(X5), G))
    #print(TurboMQ(partition(X6), G))
    #print(TurboMQ(partition(X7), G))
    #print(TurboMQ(partition(X8), G))
    #print(TurboMQ(partition(X9), G))
    #path_length = get_path_length(G)
    #path_num = get_path_num(G)
    #X = [0,0,0,0,0,0,1,1,2,2,2]
    #Y = []
    #print(path_length)
    #print(distMQ(X,path_length))
    #print(distMQ1(X,G,path_length))
    #print(distMQ2(X,G,path_num))