import re
import networkx as nx
import numpy as np
from pylab import show
from collections import Counter
'''

将文本形式的数据集(如：rcs.txt)编码再转换成DiGraph形式

'''

def load_graph(path):
    #读取文件
    with open(path) as f:
        text = f.read()
        #将读取到的内容以“空格和换行”符分割
        encode = re.split(' |\n',text)
        #将读取的字符串编码(从0开始，按行依次编码)

        code = 0
        for i in range(len(encode)):
            if isinstance(encode[i], str):
                temp = encode[i]
                #print("code",code,"encode",encode[i])
                for j in range(len(encode)):
                    if encode[j] == temp:
                        encode[j] = code
                code += 1
    #print(encode)
    #print(len(encode))
    #生成图
    G = nx.DiGraph()
    for i in range(0,len(encode),2):
        source = encode[i]
        target = encode[i+1]
        G.add_edge(source, target)

    return G

def clone_graph(G):
    cloned_g = nx.DiGraph()
    for i in G.nodes:
        cloned_g.add_node(i)
    for edge in G.edges():
        cloned_g.add_edge(edge[0], edge[1])
    return cloned_g


if __name__ == '__main__':

    #可视化
    G = load_graph("NSGA2/dataset/jdk.txt")

    indegree = []
    outdegree = []
    degree = []
    for i in G.nodes:
        if list(G.predecessors(i)) == []:
            indegree.append(i)
        if list(G.successors(i)) == []:
            outdegree.append(i)
        degree.append(G.degree(i))
    dict = Counter(degree)
    print(dict)
    print(len(dict))
    print("indegree num", len(indegree))
    print("outdegree num", len(outdegree))
    #graph = G.to_undirected()
    #for i in range(len(G.nodes)):
    #    temp = G.in_degree(i)
    #    indegree.append(temp)
    #print(indegree)
    #indegree.sort(reverse=True)
    #print(indegree)

    #for i in range(len(G.nodes)):
    #    print(i,list(G.predecessors(i)))
    #for path in nx.all_simple_paths(G, source=0, target=1):
    #    print(path)

    #for i in G.nodes:
    #    if G.out_degree(i) == 0:
    #        print(i)

    #nx.draw_networkx(G)
    #print(list(G.successors(2)))
    #print(list(G.predecessors(2)))

    #nx.draw(G,with_labels=True)
    #show()

    #print(G.adj[1])
    #print(list(G.successors(1)))
    #print(list(G.predecessors(1)))
    #print(nx.has_path(graph,0,3))





