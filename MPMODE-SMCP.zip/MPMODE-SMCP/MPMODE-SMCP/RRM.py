import random

import numpy as np

'''
去冗余策略思想：
例如：
[2,3,5,6,5,6]=>[0,1,2,3,2,3]
'''

def RRM(X):
    dim = len(X)
    label = 0
    newX = np.ones(dim) * float("inf")
    for j in range(dim):
        if (newX[j] == float("inf")):
            newX[j] = label
            for k in range(j + 1, dim):
                if (X[j] == X[k]):
                    newX[k] = newX[j]
            label += 1

    return newX

def RRM4repair(X,SSMat):

    dim = len(X)
    for i in range(dim):
        neighbor = []
        for j in range(dim):
            if SSMat[i,j] > 0 :
                neighbor.append(X[j])
        #print(neighbor)
        if neighbor != []:
            if X[i] not in neighbor:
                X[i] = random.choice(neighbor)
                #print("get repair")

    label = 0
    newX = np.ones(dim) * float("inf")
    for j in range(dim):
        if (newX[j] == float("inf")):
            newX[j] = label
            for k in range(j + 1, dim):
                if (X[j] == X[k]):
                    newX[k] = newX[j]
            label += 1

    return newX

def indiRRM(X):
    dim = len(X)
    label = 0
    newX = np.ones(dim) * float("inf")
    for j in range(dim):
        if X[j] == float("inf"):
            continue
        elif (newX[j] == float("inf")):
            newX[j] = label
            for k in range(j + 1, dim):
                if (X[j] == X[k]):
                    newX[k] = newX[j]
            label += 1
    X = np.copy(newX)

    return X

def RRM4pop(X,popsize,dim):

    for i in range(popsize):
        label = 0
        newX = np.ones(dim) * float("inf")
        for j in range(dim):
            if X[i,j] == float("inf"):
                continue
            elif (newX[j] == float("inf")):
                newX[j] = label
                for k in range(j+1,dim):
                    if (X[i,j] == X[i,k]):
                        newX[k] = newX[j]
                label += 1
        X[i] = np.copy(newX)

    return X


if __name__ == '__main__':
    X = [2,3,5,6,5,6]#X = np.array([[1,float("inf"),3],[1,1,3],[2,2,1]])
    print(RRM(X))
    print(indiRRM(X))
    print(RRM4repair(X,SSMat))