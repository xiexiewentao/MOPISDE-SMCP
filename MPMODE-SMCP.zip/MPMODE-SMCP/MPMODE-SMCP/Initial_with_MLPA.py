import collections
import random
import numpy as np
import Graphhelper as gh
#from RRM import RRM
#from TurboMQ import TurboMQ
from TurboMQ import NewTurboMQ,TurboMQ
from partition import partition
from RRM import RRM

'''
编码方式：
    编码：     [1,1,1,1,2,2,2]
    数组下标：   0,1,2,3,4,5,6
    即表示点{0,1,2,3}在社区1，点{4,5,6}在社区2

基本的标签传播算法(LPA)思想：
让每个结点与它的大多数邻居在同一个社区中。
具体算法流程为：
初始化，每个结点携带一个唯一的标签；
然后更新结点的标签，令其标签与它的大多数邻居的标签相同，若存在多个则随机选择。
迭代直至每个结点的标签不再变化。

'''
def get_random_neighGlobals(G,labels):


    global_modules = []
    dim = len(G.nodes)
    for i in range(dim):
        if ((G.in_degree(i)) > 1 and (G.out_degree(i) == 0)):
            labels[i] = dim
            #print("original element",i)

    return labels

def get_random_neighbours(G,kk):
    dim = len(G.nodes)
    labels = np.zeros(dim)

    for i in range(dim):
        labels[i] = i
    for i in range(dim):
        a = []
        alen = -1
        for j in G.predecessors(i):
            a.append(j)
        for j in G.successors(i):
            a.append(j)
        alen = len(a) - 1
        if alen > 0:
            k = random.randint(0,alen)
            labels[i] = a[k]
    if kk == 1:
        labels = get_random_neighGlobals(G, labels)

    return labels


def diff_Graph(G,  c):
    dim = len(G.nodes)
    dataSet = np.zeros((dim, dim), np.float32)
    max_indegree = 0
    max_outdegree = 0
    max_degree = 0
    sum = 2*len(G.edges)
    ratio = sum/dim
    sum_indegree = 0
    sum_outdegree = 0
    dense = []

    if c == 'in':
        for i in range(dim):
            predecessors = list(G.predecessors(i))
            for j in predecessors:
                dataSet[i][j] = 1
    if c == 'out':
        for i in range(dim):
            predecessors = list(G.successors(i))
            for j in predecessors:
                dataSet[i][j] = 1
    if c == 'in':
        for i in range(dim):
            predecessors = list(G.predecessors(i))
            for j in predecessors:
                dataSet[i][j] = 1
    if c == 'all':
        for i in range(dim):
            predecessors = list(G.neighbors(i))
            for j in predecessors:
                dataSet[i][j] = 1

    for i in range(dim):
        in_degree = G.in_degree(i)
        out_degree = G.out_degree(i)
        sum_indegree += in_degree
        sum_outdegree += out_degree
        if out_degree > max_outdegree:
            max_outdegree = out_degree
        if in_degree > max_indegree:
            max_indegree = in_degree

        k = in_degree + out_degree
        if k > max_indegree:
            max_indegree = k
        if k > ratio:
            dense.append(i)

        #print("dataset",dataSet)
    return dataSet,dense


def navie_knn(dataSet, G,query, k,kk):
    ## step 1: calculate Euclidean distance
    numSamples = dataSet.shape[0]
    #diff = np.tile(query, (numSamples, 1)) - dataSet
    squaredDiff = []
    if kk == 1:
        for i in G.nodes:
            diff = list(set(G.neighbors(query)).intersection(G.neighbors(i)))
            #print("diff", diff)
            squaredDiff.append(-len(diff))
    #squaredDist = np.sum(squaredDiff, axis=1)  # sum is performed by row

    ## step 2: sort the distance
    sortedDist = np.argsort(squaredDiff)
    #print("sort", sortedDist)
    if k > len(sortedDist):
        k = len(sortedDist)

    return sortedDist[1:k]


def buildGraph(MatX, kernel_type, rbf_sigma=None, knn_num_neighbors=None):
    num_samples = len(MatX.nodes)
    affinity_matrix = np.zeros((num_samples, num_samples),np.float32)
    if kernel_type == 'rbf':
        if rbf_sigma == None:
            raise ValueError('You should input a sigma of rbf kernel!')
        for i in range(num_samples):
            row_sum = 0.0
            for j in range(num_samples):
                diff = MatX[i, :] - MatX[j, :]
                affinity_matrix[i][j] = np.exp(sum(diff ** 2) / (-2.0 * rbf_sigma ** 2))
                row_sum += affinity_matrix[i][j]
            affinity_matrix[i][:] /= row_sum
    elif kernel_type == 'knn':
        GG,La = diff_Graph(MatX,  "all")
        if knn_num_neighbors == None:
            raise ValueError('You should input a k of knn kernel!')
        for i in range(num_samples):
            k_neighbors = navie_knn(GG,MatX, i, knn_num_neighbors,1)
            affinity_matrix[i][k_neighbors] = knn_num_neighbors #1.0 / knn_num_neighbors
        #print("matrix",affinity_matrix)
    else:
        affinity_matrix,k1 = diff_Graph(MatX, "all")

    return affinity_matrix

def labelPropagation(G,labels,dim,max_iter,tol,kernel_type, rbf_sigma, knn_num_neighbors):
      # labels_list = np.unique(labels)
    # print("initial:", labels,"class number ",num_classes)
    labels_list = np.argsort(labels)
    num_classes = len(labels)
    num_label_samples = num_classes
    num_unlabel_samples = dim - num_label_samples
    num_samples = dim
    # Mat_Label = np.ones((num_label_samples, num_classes), np.float32)
    # MatX = np.ones((num_samples, num_classes), np.float32)
    label_function = np.zeros((num_samples, num_classes), np.float32)
    label_final = np.zeros(dim)

    for i in range(num_classes):
        label_function[labels[labels_list[i]]][i] = 1
        # print("i", labels_list[i], "j", labels[labels_list[i]])
    # graph construction
    affinity_matrix = buildGraph(G, kernel_type, rbf_sigma, knn_num_neighbors)
    # print(label_function)
    # print("affi", affinity_matrix)
    # start to propagation
    iter = 0
    pre_label_function = np.zeros((num_samples, num_classes), np.float32)
    changed = np.abs(pre_label_function - label_function).sum()

    while iter < max_iter and changed > tol:
        if iter % 1 == 0:
            print
            "---> Iteration %d/%d, changed: %f" % (iter, max_iter, changed)
        pre_label_function = label_function
        iter += 1

        # propagation
        label_function = np.dot(affinity_matrix, label_function)

        # print(label_function)
        # clamp
        for i in range(num_classes):
            for j in range(num_classes):
                label_function[labels[labels_list[i]]][j] = 0
            label_function[labels[labels_list[i]]][i] = 1

        # check converge
        changed = np.abs(pre_label_function - label_function).sum()
        # print("change",changed)
        # get terminate label of unlabeled data
    for i in range(dim):
        j = np.argmax(label_function[i])
        label_final[i] = labels[labels_list[j]]
        # print("lable",label_function[i],"the max",label_final[i],"max",np.argmax(label_function[i]))
    return label_final

def labelGeneration(G, max_iter,adjust,kernel_type, rbf_sigma,knn_num_neighbors, tol):
    # initialize
    dim = len(G.nodes)
    if adjust < 3:
        if adjust == 0:
            labels = random.sample(G.nodes, int(1/4*dim * random.random())+2)
            kernel_type = 'kn'
        elif adjust == 1:
            labels = random.sample(G.nodes, int(1/4*dim * random.random())+2)
            kernel_type = 'knn'
        elif adjust == 2:
            affinity_matrix,lab = diff_Graph(G, "all")
            labels = random.sample(lab, min(len(lab)-1,int(1 / 4 * len(lab) * random.random()) + 2))
            kernel_type = 'kn'
        elif adjust == 2:
            affinity_matrix, lab = diff_Graph(G, "all")
            labels = random.sample(lab, int(1 / 4 * len(lab)* random.random()) + 2)
            kernel_type = 'knn'

        label_final = labelPropagation(G, labels, dim, max_iter, tol, kernel_type, rbf_sigma, knn_num_neighbors)

    else:
        label_final = get_random_neighbours(G,1)

    return label_final

def init(G,unfroze):
    n = len(G.nodes)
    nodeSect = []

    ind = np.empty(n)
    ind.fill(np.inf)
    label = 0
    set3 = []
    for k in unfroze:
        neibor1 = (list(G.predecessors(k)) + list(G.successors(k)))
        if ind[k] == np.inf:
            for neibor in neibor1:
                neibor2 = (list(G.predecessors(neibor)) + list(G.successors(neibor)))
                set1 = list(set(neibor1).intersection(neibor2))
                if set1 != []:
                    set2 = set(set1).union([neibor])
                    set2 = set(set2).union([k])  # print("set2",set2) #print("n",nodeInsect)
                    if set2 not in nodeSect:
                        nodeSect.append(set2)
                        for j in set2:
                            ind[j] = label
                        label += 1

    len1 = len(nodeSect)#print("first label",label,newind )
    sect = []
    for i in range(len1):
        sect.append(list(nodeSect[i]))
    nodeSect = sect.copy()
    return nodeSect

def com_unfroze(G):
    n = len(G.nodes)
    froze = []
    unfroze = []
    du = G.degree()

    for i in range(n):
        if G.degree(i) != 0:
            unfroze.append(i)#print("i",i,neibors)
        else:
            froze.append(i)
    return unfroze,froze

def LPA(G,popsize,dim,Max_iter):
    # 初始化标签，每个结点携带一个唯一的标签
    X = float("inf") * np.ones((popsize,dim))
    unfroze, froze = com_unfroze(G)

    initial = init(G, unfroze)
    kk = len(initial)
    for i in range(popsize):
        label = dim
        for ii in range(kk):
            for j in initial[ii]:
                X[i, j] = label
            label += 1
    pop = popsize//5
    #print("popsize",popsize,"pp",pop)
    for i in range(popsize):
        if pop == 0:
            adjust = 0
        else:
            adjust = i//pop
        #print("adjust",adjust)
        X[i:] = labelGeneration(G, Max_iter, adjust, kernel_type='kn', rbf_sigma=1.5, knn_num_neighbors=10, tol=1e-3)

    return X


if __name__ == '__main__':
    G = gh.load_graph("NSGA2/dataset/rcs.txt")
    popsize = 50
    dim = len(G.nodes)
    Max_iter = 20

    X = LPA(G,popsize,dim,Max_iter)
    for i in range(popsize):
        cs = RRM(X[i, :])
        print(TurboMQ(partition(cs), G))
