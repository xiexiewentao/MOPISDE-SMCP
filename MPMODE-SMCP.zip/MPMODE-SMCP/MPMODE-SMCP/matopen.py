import scipy.io as scio

def load_graph(path,type):

    data = scio.loadmat(path)
    matrix = data[type]

    return matrix

if __name__ == '__main__':

    semantic = load_graph("NSGA2/dataset/Semantic/browser.mat", "SemanticGraph")
    print(semantic)
    nomial = load_graph("NSGA2/dataset/Nomial/browser.mat", "NameSimilarity")
    print(nomial)
    call = load_graph("NSGA2/dataset/Call/browser.mat", "GraphDependency")
    print(call)
