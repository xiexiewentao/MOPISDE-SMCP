import numpy as np
import networkx as nx
from RRM import RRM,indiRRM,RRM4repair
from Ca_and_Ce import get_Instability
from MoJoFM import MoJoFM
from F_measure import get_F_measure
from MS import get_similarity
from TurboMQ import TurboMQ,NewTurboMQ
from TurboMQ import get_sum_of_intra_edge,get_sum_of_inter_edge,distMQ,distMQ1,distMQ3
from C2C import C2CCalculation
from Mutation_individual_with_neighbor import mutatio, mutated
#from Crossover_oneway import crossoverPopulaton
from Crossover_three_Individual import crossover,crossover1,crossfreq1
import matrix_to_graph as m2g
import Graphhelper as gh
import matplotlib.pyplot as plt
from Initial_with_random import LPA_NEW
import random
import numpy as np
from partition import partition
from frequency import cal_Fre,inter_Fre,difference_sect1,difference_sect
import time
import xlrd
import xlutils.copy

def get_path_length(G):
    dim = len(G.nodes)
    shortest_path_length = np.zeros([dim, dim])
    for i in range(dim):
        for j in range(dim):
            if (i != j) and (nx.has_path(G, i, j)):
                shortest_path_length[i, j] = nx.shortest_path_length(G, i, j)
            else:
                shortest_path_length[i, j] = 0

    return shortest_path_length

def get_sim(G):
    dim = len(G.nodes)
    sim_matrix = np.zeros([dim, dim])
    for i in range(dim):
        for j in range(dim):
            if i != j :
                sim_matrix[i, j] = get_similarity(i, j, G)
            else:
                sim_matrix[i, j] = 0

    return sim_matrix

def get_path_num(G):

    dim = len(G.nodes)
    path_num = np.zeros([dim, dim])
    for i in range(dim):
        for j in range(dim):
            if (i != j) and (nx.has_path(G, i, j)):
                path_num[i, j] = 1
            else:
                path_num[i, j] = 0

    return path_num
#去重复策略
def clearDups(Population,G):

    newPopulation = np.unique(Population, axis=0)
    oldLen = len(Population)
    newLen = len(newPopulation)
    LPA_max_itr = 20
    if newLen < oldLen:
        nDuplicates = oldLen - newLen
        X = LPA_NEW(G,nDuplicates,0.5)
        newPopulation = np.append(newPopulation, X, axis=0)
        print("get clear")

    return newPopulation

def PSO(popsize,max_iters,G,B,thcvg,m1):

    mp = 0.5
    dim = len(G.nodes)
    cp = 0.5
    p_mu = 0.5
    bestScoreUnchanged = 0
    scorestq = np.random.uniform(0.0, 1.0, popsize)
    scoresmf = np.random.uniform(0.0, 1.0, popsize)
    scoresms = np.random.uniform(0.0, 1.0, popsize)
    ms = np.ones(popsize)
    global_best_Score = np.zeros([3])
    global_worst_Score = np.zeros([3])
    curMax = np.zeros([3])#local_best_Score = np.zeros(popsize)
    curMin = np.zeros([3])
    #local_best = np.zeros((popsize,dim), np.float32)
    LPA_max_itr = 5
    bestIndividual = np.zeros((3,dim), np.float32)
    worstIndividual = np.zeros((3, dim), np.float32)
    cluster_num = np.ones(popsize)
    X = np.zeros((popsize,dim), np.float32)

    #neu_swarm = LPA(G,popsize,dim,LPA_max_itr)#:LPA(G, popsize, dim, LPA_max_itr)
    X = LPA_NEW(G,popsize,0.1)
    #male_swarm = LPA(G, popsize, dim, LPA_max_itr)
    shortest_path_length = get_path_length(G)
    sim_mat = get_sim(G)
    #print(sim_mat)
    progress = []
    change = 0

    global_best_Score[0] = 0
    global_best_Score[1] = 0
    global_best_Score[2] = 0
    #clusterB = partition(B)

    for l in range(max_iters):
        for diff in range(1):
            for i in range(popsize):
                if diff == 1:
                    X[i] = RRM4repair(X[i],sim_mat)
                    # cs = partition(male_swarm[i])   #clusterMs.append(cs)
                    # scoresms[i],global_module = MS(male_swarm[i], G)
                    scoresms[i] = get_Instability(partition(X[i]), G)

                elif diff == 0:
                    X[i] = RRM4repair(X[i],sim_mat)
                    cs = partition(X[i])  # clustertq.append(cs)
                    # scorestq[i] = TurboMQ(cs,G)
                    scorestq[i] = NewTurboMQ(X[i], cs, G)
                    # TurboMQ(female_swarm[i, :], G)
                elif diff == 2:
                    X[i] = RRM4repair(X[i],sim_mat)
                    scoresmf[i] = distMQ3(X[i], G, shortest_path_length)

            progress.append([np.mean(scorestq), np.mean(scoresms), np.mean(scoresmf)])
            if diff == 1:
                sortidx = np.argsort(scoresms)[::-1]
                X = X[sortidx].copy()
                curMax[diff] = max(scoresms)


            elif diff == 0:
                sortidx = np.argsort(scorestq)[::-1]
                X = X[sortidx].copy()  # print("scorestq", scorestq)
                scorestq = scorestq[sortidx].copy()
                curMax[diff] = max(scorestq)


            elif diff == 2:
                # print("i scoresmf")
                sortidx = np.argsort(scoresmf)[::-1]
                X = X[sortidx].copy()  # print("scorestq", scorestq)
                curMax[diff] = max(scoresmf)


            if curMax[diff] > global_best_Score[diff]:
                global_best_Score[diff] = curMax[diff]
                bestIndividual[diff] = X[0].copy()  # scores[0] = TurboMQ(bestIndividual, G)
                print("iter", l, "change", i, "score", global_best_Score[diff], "male",diff)  # print("max score", max(scores), scores[0])  #print("best individual", bestIndividual )
                bestScoreUnchanged = 0
            else:
                bestScoreUnchanged += 1

            for i in range(popsize):

                #ind = X[i].copy()
                #r3 = 0.9
                #for j in range(dim):
                #    if random.random() < r3:
                #       ind[j] = bestIndividual[diff,j]
                ind = X[i].copy()
                diffset = difference_sect1(bestIndividual[diff], X[i])

                for j in diffset:
                    neighbor = []
                    for k in range(dim):
                        if (sim_mat[j, k] > 0):
                            neighbor.append(k)
                    if neighbor != []:
                        alpha = len(neighbor)
                        #print("alpha",alpha)
                        r1 = alpha - l * (alpha / max_iters)
                        r2 = (2 * np.pi) * random.random()
                        r4 = random.random()
                        #print(r1,np.sin(r2),np.cos(r2),r4)
                        if r4 < 0.5:
                            gamma = int(r1 * np.sin(r2))
                        else:
                            gamma = int(r1 * np.cos(r2))
                        #print("gamma",gamma)
                        sim = []
                        for k in range(dim):
                            if ind[k] == ind[j] and sim_mat[j,k] > 0:
                                sim.append(sim_mat[j,k])
                        if sim != []:
                            if gamma > 0 :
                                if sim_mat[j, neighbor[gamma]] > min(sim):
                                    ind[j] = ind[neighbor[gamma]]
                            else:
                                if sim_mat[j, neighbor[gamma]] < max(sim):
                                    ind[j] = ind[neighbor[gamma]]

                ind = RRM4repair(ind,sim_mat)
                if diff == 1:
                    # score1,global_module = MS(ind, G)
                    score1 = get_Instability(partition(ind), G)
                    mutationProbability = random.uniform(0.0, 1.0)
                    if (score1 > scoresms[i]) and (mutationProbability < 1):
                        scoresms[i] = score1
                        X[i] = ind.copy()

                elif diff == 0:
                    score1 = NewTurboMQ(ind, partition(ind), G)  # TurboMQ(ind, G)
                    mutationProbability = random.uniform(0.0, 1.0)
                    if (score1 > scorestq[i]) and (mutationProbability < 1):
                        scorestq[i] = score1
                        X[i] = ind.copy()
                        print("ind sca success, diff, k, j",score1,l,i)

                elif diff == 2:
                    score1 = distMQ3(ind, G, shortest_path_length)
                    mutationProbability = random.uniform(0.0, 1.0)
                    if (score1 > scoresmf[i]) and (mutationProbability < 1):
                        scoresmf[i] = score1
                        X[i] = ind.copy()

                if score1 > global_best_Score[diff]:
                    global_best_Score[diff] = score1
                    bestIndividual[diff] = X[i].copy()
                    bestScoreUnchanged = 0
                    print("sca success, diff, k, j", global_best_Score[diff], i)
                else:
                    bestScoreUnchanged += 1

            for i in range(popsize):
                ind = X[i].copy()
                replace_nodes = random.sample(range(0, popsize - 1), round(2))  # 集合的差
                #diffset1 = difference_sect(X, replace_nodes)

                z = random.random()
                for k in range(2):
                    if k == 0 :
                        for j in range(dim):
                            ind[j] = X[replace_nodes[0],j] + X[replace_nodes[1],j]
                    else:
                        for j in range(dim):
                            ind[j] = X[i,j] + z * (X[replace_nodes[0],j] - X[replace_nodes[1],j])

                    ind = RRM4repair(ind,sim_mat)
                    if diff == 1:
                    # score1,global_module = MS(ind, G)
                        score1 = get_Instability(partition(ind), G)
                        mutationProbability = random.uniform(0.0, 1.0)
                        if (score1 > scoresms[i]) and (mutationProbability < 1):
                            scoresms[i] = score1
                            X[i] = ind.copy()

                    elif diff == 0:
                        score1 = NewTurboMQ(ind, partition(ind), G)  # TurboMQ(ind, G)
                        mutationProbability = random.uniform(0.0, 1.0)
                        if (score1 > scorestq[i]) and (mutationProbability < 1):
                            scorestq[i] = score1
                            X[i] = ind.copy()
                            print("ind De success, diff, k, j", score1, l,k)

                    elif diff == 2:
                        score1 = distMQ3(ind, G, shortest_path_length)
                        mutationProbability = random.uniform(0.0, 1.0)
                        if (score1 > scoresmf[i]) and (mutationProbability < 1):
                            scoresmf[i] = score1
                            X[i] = ind.copy()

                    if score1 > global_best_Score[diff]:
                        global_best_Score[diff] = score1
                        bestIndividual[diff] = X[i].copy()
                        bestScoreUnchanged = 0
                        print("de success, diff, k, j", global_best_Score[diff], diff,k)
                    else:
                        bestScoreUnchanged += 1

            X = clearDups(X, G)
        progress.append(global_best_Score[0])


    print("global", global_best_Score)
    #plt.xlim(0, l)
    #plt.ylim(1.5, 2.2)
    #plt.plot(progress)
    #plt.show()

    return global_best_Score[0],global_best_Score[1],global_best_Score[2],bestIndividual

def run(i):

    G = m2g.load_graph("NSGA2/dataset/Mozilla Firefox_matrix/accessible.txt")
    # G = gh.load_graph("dataset/rcs.txt")
    dim = len(G.nodes)
    popsize = 50
    Max_iteration = 100
    thcvg = 0.33

    # B = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,2,2,0,6,2,2,2,2,2,2,2,2,2,2,2,6,6,2,2,2,3,2,2,2,2,2,2,0,6,6,6,2,2,1,6,2,2,2,2,2,2,2,2,1,6,0,2,2,2,2,4,4,4,4,0,6,4,4,4,4,4,4,4,4,0,6,4,4,0,0,4,4,0,6,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,1,2,2,6,6,1,2,2,0,6,2,2,2,2,0,0,7,7,7,7,7,7,8,8,8,8,8,8,8,8,8,8,0,6,8,8,0,6,8,8,8,8,8,8,8,8,8,8,0,6]
    B = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,2,2,0,6,2,2,2,2,2,2,2,2,2,2,2,6,6,2,2,2,3,2,2,2,2,2,2,0,6,6,6,2,2,1,6,2,2,2,2,2,2,2,2,1,6,0,2,2,2,2,4,4,4,4,0,6,4,4,4,4,4,4,4,4,0,6,4,4,0,0,4,4,0,6,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,1,2,2,6,6,1,2,2,0,6,2,2,2,2,0,0,7,7,7,7,7,7,8,8,8,8,8,8,8,8,8,8,0,6,8,8,0,6,8,8,8,8,8,8,8,8,8,8,0,6]

    # B = [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,1,1,3]
    # B = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,2,2,0,6,2,2,2,2,2,2,2,2,2,2,2,6,6,2,2,2,3,2,2,2,2,2,2,0,6,6,6,2,2,1,6,2,2,2,2,2,2,2,2,1,6,0,2,2,2,2,4,4,4,4,0,6,4,4,4,4,4,4,4,4,0,6,4,4,0,0,4,4,0,6,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,1,2,2,6,6,1,2,2,0,6,2,2,2,2,0,0,7,7,7,7,7,7,8,8,8,8,8,8,8,8,8,8,0,6,8,8,0,6,8,8,8,8,8,8,8,8,8,8,0,6]

    # print("par",partition(B))
    # m1 = TurboMQ(partition(B), G)
    # m2,mu = NewTurboMQ(B,partition(B),G)

    # predecessors = list(G.predecessors(0))
    # successors = list(G.successors(0))
    # print("The node out one :",len(G.nodes),len(B),m1,m2,mu)
    # X = random.sample(G.nodes, int(G.nodes * random.random()))
    # X= random.randint(0, G.nodes, G.nodese)

    # ms,global_modules = MS(li, G)
    # print("global_modules:", global_modules)
    best_score0, best_score1, best_score2, best_individual = PSO(popsize, Max_iteration, G, B, thcvg, 1)
    # print("The Best c2c value:", C2CCalculation(best_individual[0],B,thcvg))
    MQ2 = TurboMQ(partition(best_individual[1]), G)
    MQ3 = TurboMQ(partition(best_individual[2]), G)
    mojo1 = MoJoFM(best_individual[0], B)
    mojo2 = MoJoFM(best_individual[1], B)
    mojo3 = MoJoFM(best_individual[2], B)
    precision1, recall1, fm1 = get_F_measure(best_individual[0], B)
    precision2, recall2, fm2 = get_F_measure(best_individual[1], B)
    precision3, recall3, fm3 = get_F_measure(best_individual[2], B)
    print("The Best  MQ value of obj2:", MQ2)
    print("The Best  MQ value of obj3:", MQ3)
    print("The Best  MoJoFM value of obj1:", mojo1)
    print("The Best  MoJoFM value of obj2:", mojo2)
    print("The Best  MoJoFM value of obj3:", mojo3)
    print("The Best  FM value of obj1:", fm1)
    print("The Best  FM value of obj2:", fm2)
    print("The Best  FM value of obj3:", fm3)
    print("The Best clustering:", best_individual)
    # print("The Best MQ value:",TurboMQ(best_individual,G))
    # bestind = best_individual[0].tolist()


if __name__ == '__main__':

    timerStart = time.time()
    for i in range(1):
        print('get'+ str(i))
        run(i)
    timerEnd = time.time()
    print("time",str(timerEnd-timerStart))

