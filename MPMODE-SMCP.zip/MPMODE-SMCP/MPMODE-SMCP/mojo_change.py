import numpy as np
from RRM import RRM,indiRRM
from MoJoFM import MoJoFM
from TurboMQ import TurboMQ,NewTurboMQ
from TurboMQ import get_sum_of_intra_edge,M1
from C2C import C2CCalculation
from Mutation_individual_with_neighbor import mutatio, mutated
#from Crossover_oneway import crossoverPopulaton
from Crossover_three_Individual import crossover,crossover1,crossfreq
import Graphhelper as gh
import matplotlib.pyplot as plt
from Initial_with_LPA import LPA
from reinitialization import LPA_NEW
import random
import numpy as np
from partition import partition
from frequency import cal_Fre,inter_Fre,difference_sect
import time
import xlrd
import xlutils.copy

#去重复策略
def clearDups(Population,dim,G):

    newPopulation = np.unique(Population, axis=0)
    oldLen = len(Population)
    newLen = len(newPopulation)
    LPA_max_itr = 5
    if newLen < oldLen:
        nDuplicates = oldLen - newLen
        X = LPA(G, nDuplicates, dim, LPA_max_itr)
        newPopulation = np.append(newPopulation, X , axis=0)

    return newPopulation

def PSO(popsize,max_iters,G,B,thcvg,m1):

    mp = 0.5
    dim = len(G.nodes)
    cp = 0.5
    p_mu = 0.5
    bestScoreUnchanged = 0
    scorestq = np.random.uniform(0.0, 1.0, popsize)
    scoresmf = np.random.uniform(0.0, 1.0, popsize)
    scoresms = np.random.uniform(0.0, 1.0, popsize)
    ms = np.ones(popsize)
    global_best_Score = np.zeros([3])
    curMax = np.zeros([3])#local_best_Score = np.zeros(popsize)
    #local_best = np.zeros((popsize,dim), np.float32)
    LPA_max_itr = 20
    bestIndividual = np.zeros((3,dim), np.float32)
    cluster_num = np.ones(popsize)
    X = np.zeros((popsize,dim), np.float32)

    neu_swarm = LPA(G,popsize,dim,LPA_max_itr)
    female_swarm = LPA(G, popsize, dim, LPA_max_itr)
    male_swarm = LPA(G, popsize, dim, LPA_max_itr)
    progress = []
    change = 0

    global_best_Score[0] = 0
    global_best_Score[1] = 0
    global_best_Score[2] = 0
    #clusterB = partition(B)

    for l in range(max_iters):
        for diff in range(3):
            for i in range(popsize):
                if diff == 1:
                    male_swarm[i] = RRM(male_swarm[i])
                    #cs = partition(male_swarm[i])   #clusterMs.append(cs)
                    scoresms[i] = get_sum_of_intra_edge(partition(male_swarm[i]), G)
                elif diff == 0:
                    female_swarm[i] = RRM(female_swarm[i])
                    cs = partition(female_swarm[i])     #clustertq.append(cs)
                    scorestq[i],mult = NewTurboMQ(female_swarm[i],cs,G)# TurboMQ(female_swarm[i, :], G)
                elif diff == 2:
                    neu_swarm[i] = RRM(neu_swarm[i])
                    scoresmf[i] = M1(partition(neu_swarm[i]),G)

            if diff == 1:
                sortidx = np.argsort(scoresms)[::-1]
                X = male_swarm[sortidx].copy()
                curMax[diff] = max(scoresms)
            elif diff == 0:
                sortidx = np.argsort(scorestq)[::-1]
                X = female_swarm[sortidx].copy()#print("scorestq", scorestq)
                curMax[diff] = max(scorestq)
            elif diff == 2:
                #print("i scoresmf")
                sortidx = np.argsort(scoresmf)[::-1]
                X = neu_swarm[sortidx].copy()  # print("scorestq", scorestq)
                curMax[diff] = max(scoresmf)
                #print("scoresmf", curMax,scoresmf)

            if curMax[diff] > global_best_Score[diff]:
                global_best_Score[diff] = curMax[diff]
                bestIndividual[diff] = X[0].copy()   #scores[0] = TurboMQ(bestIndividual, G)
                print("iter", l, "change",i,"score",global_best_Score[diff],"male",diff)   #print("max score", max(scores), scores[0])  #print("best individual", bestIndividual )
                bestScoreUnchanged = 0
            else:
                bestScoreUnchanged += 1

            keep = int(0.1 * popsize)
            limit1 = popsize
            for j in range(2):
                if j == 0:
                    freq, rest = cal_Fre(X, 3 + change // 5, bestScoreUnchanged, G)#集合的交
                else:
                    replace_nodes = random.sample(range(0, popsize-1), round(2))#集合的差
                    freq = difference_sect(X, replace_nodes)

                for i in range(keep, limit1):
                    for k in range(2):
                        if k == 0:
                            ind = crossfreq(X, i,freq)##根据频繁集改进
                        else:
                            ind = mutated(G, X[i], freq)
                        ind = RRM(ind)
                        if diff == 1:
                            score1 = get_sum_of_intra_edge(partition(ind), G)
                            mutationProbability = random.uniform(0.0, 1.0)
                            if (score1 > scoresms[i]) | (mutationProbability < 0.7):
                                scoresms[i] = score1
                                X[i] = ind.copy()

                        elif diff == 0:
                            score1, mult = NewTurboMQ(ind,partition(ind),G)#TurboMQ(ind, G)
                            mutationProbability = random.uniform(0.0, 1.0)
                            if (score1 > scorestq[i]) | (mutationProbability < 0.2):
                                scorestq[i] = score1
                                X[i] = ind.copy()

                        elif diff == 2:
                            score1 = M1(partition(ind),G)
                            mutationProbability = random.uniform(0.0, 1.0)
                            if (score1 > scoresmf[i]) | (mutationProbability < 0.7):
                                scoresmf[i] = score1
                                X[i] = ind.copy()

                        if score1 > global_best_Score[diff]:
                            global_best_Score[diff] = score1
                            bestIndividual[diff] = X[i].copy()
                            bestScoreUnchanged = 0
                            print("freq success", global_best_Score[diff],diff)
                        else:
                            bestScoreUnchanged += 1


            if diff == 1:
                male_swarm = X.copy()
            elif diff == 0:
                female_swarm = X.copy()
            elif diff == 2:
                neu_swarm = X.copy()

            for i in range(limit1, popsize):  #
                kk = i - limit1
                ind = X[i].copy()
                if diff == 1:
                    ind = crossover1(male_swarm[kk], female_swarm[kk], neu_swarm[kk], 0.5)
                    ind = RRM(ind)
                    score1 = get_sum_of_intra_edge(partition(ind), G)
                    mutationProbability = random.uniform(0.0, 1.0)
                    if (score1 > scoresms[i]) | (mutationProbability < 0.6):
                        scoresms[i] = score1
                        male_swarm[i] = ind.copy()

                elif diff == 0:
                    ind = crossover1(female_swarm[kk], male_swarm[kk], neu_swarm[kk], 0.5)
                    ind = RRM(ind)
                    score1, mult = NewTurboMQ(ind, partition(ind), G)  # TurboMQ(ind, G)
                    mutationProbability = random.uniform(0.0, 1.0)
                    if (score1 > scorestq[i]) | (mutationProbability < 0.6):
                        scorestq[i] = score1
                        female_swarm[i] = ind.copy()

                elif diff == 2:
                    ind = crossover1(neu_swarm[kk], female_swarm[kk], male_swarm[kk], 0.5)
                    ind = RRM(ind)
                    score1 = M1(partition(ind),G)
                    mutationProbability = random.uniform(0.0, 1.0)
                    if (score1 > scoresmf[i]) | (mutationProbability < 0.7):
                        scoresmf[i] = score1
                        neu_swarm[i] = ind.copy()

                if score1 > global_best_Score[diff]:
                    global_best_Score[diff] = score1
                    bestIndividual[diff] = ind.copy()
                    bestScoreUnchanged = 0
                    print("mutated cross success", global_best_Score[diff], diff)
                else:
                    bestScoreUnchanged += 1
            if bestScoreUnchanged == 30:
                bestScoreUnchanged = 0

        progress.append(global_best_Score[0])
    print("global", global_best_Score)
    #plt.xlim(0, 200)
    #plt.ylim(1.5, 2.2)
    #plt.plot(progress)
    #plt.show()

    return global_best_Score[0],global_best_Score[1],global_best_Score[2],bestIndividual

def run(i):

    G = gh.load_graph("NSGA2/dataset/mtunis.txt")
    dim = len(G.nodes)
    print("N:",dim)
    popsize = 10 * dim
    Max_iteration = 15 * dim
    thcvg  = 0.33

    B = [0,0,1,1,1,2,3,4,3,3,3,3,5,3,3,3,3,3,3,3,3,3,3,3,3,4,5,5,5,3,3,3,5,5,3,3,3,3,6,6,3,3,5]
    print("par",partition(B))
    m1 = TurboMQ(partition(B), G)
    m2,mu = NewTurboMQ(B,partition(B),G)

    #predecessors = list(G.predecessors(0))
    #successors = list(G.successors(0))
    print("The node out one :",len(G.nodes),len(B),m1,m2,mu)
    #X = random.sample(G.nodes, int(G.nodes * random.random()))
    #X= random.randint(0, G.nodes, G.nodese)

    #ms,global_modules = MS(li, G)
    #print("global_modules:", global_modules)
    best_score0, best_score1,best_score2,best_individual = PSO(popsize,Max_iteration,G,B,thcvg,1)
    print("The Best TurboMQ value:", best_score0)
    #print("The Best c2c value:", C2CCalculation(best_individual[0],B,thcvg))
    #print("The Best  MoJoFM value:", MoJoFM(best_individual[0],B))
    print("The Best clustering:", best_individual)
    #print("The Best MQ value:",TurboMQ(best_individual,G))
    #bestind = best_individual[0].tolist()

    data = xlrd.open_workbook('test.xls')  # 读入表格
    ws = xlutils.copy.copy(data)  # 复制之前表里存在的数据
    table = ws.get_sheet(0)
    table.write(i, 0, label = best_score0)  # 追加数据
    table.write(i, 1, label = best_score1)  # 追加数据
    table.write(i, 2, label = best_score2)  # 追加数据
    #table.write(i, 3, label = C2CCalculation(best_individual[0], B, thcvg))  # 追加数据
    #table.write(i, 4, label = MoJoFM(best_individual[0], B))  # 追加数据
    ws.save('test.xls')  # 保存的有旧数据和新数据

if __name__ == '__main__':

    timerStart = time.time()
    for i in range(10):
        print('get'+ str(i))
        run(i)
    timerEnd = time.time()
    print("time",str(timerEnd-timerStart))