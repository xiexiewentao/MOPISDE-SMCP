import math
import copy
import random
import numpy as np
from TurboMQ import TurboMQ,NewTurboMQ
from partition import partition
import Graphhelper as gh

#获取较优解交集
def cal_Fre(comm, num, condition, G):

    #for i in range(num):
    #    print(comm[i])
    #    print(TurboMQ(partition(comm[i]),G))
    # 边的个数
    n = len(G.nodes)
    edges = G.edges()
    nodeset = []
    # 通过节点对（同一个社区内的节点对）计算
    for j in range(num):
        set2 = []
        max1 = np.max(comm[j])+1
        for i in range(int(max1)):
            nodes1 = [k for (k, v) in enumerate(comm[j]) if v == i]
            if nodes1 != []:
                set2.append(nodes1)
        nodeset.append(set2)
    #print("nodeset",nodeset)
    Freq = []
    if condition == 0:
        set2 = nodeset[0].copy()
        for i1 in range(1, num):
            Freq = []
            for j1 in range(len(set2)):
                nodes1 = set2[j1]#set2[j]
                for k1 in range(len(nodeset[i1])):
                    nodes2 = nodeset[i1][k1]
                    set1 = list(set(nodes1).intersection(nodes2))
                    if len(set1) > 1:
                        Freq.append(set1)
            set2 = Freq.copy()
    else:
        k = np.random.randint(num-1)
        set2 = nodeset[k].copy()
        for i1 in range(0,num):
            if i1 != k:
                Freq = []
                for j1 in range(len(set2)):
                    nodes1 = set2[j1]  # set2[j]
                    for k1 in range(len(nodeset[i1])):
                        nodes2 = nodeset[i1][k1]
                        set1 = list(set(nodes1).intersection(nodes2))
                        if len(set1) > 1:
                            Freq.append(set1)
                set2 = Freq.copy()
    #print("Freq", Freq)
    res=[]
    if len(Freq) > 0:
        for i in range(len(Freq)):
            res = list(set(res).union(Freq[i]))
    #print("res",res)
    rest = []
    for i in range(n):
        if i not in res:
            rest.append(i)

    return Freq, rest

def inter_Fre(comm, num, G):
    # 边的个数
    n = len(G.nodes)
    edges = G.edges()
    m = len(edges)
    # 每个节点的度
    du = G.degree()
    nodeset = []
    # 通过节点对（同一个社区内的节点对）计算
    for j in num:
        set2 = []
        max1 = np.max(comm[j])+1
        for i in range(int(max1)):
            nodes1 = [k for (k, v) in enumerate(comm[j]) if v == i]
            if nodes1 != []:
                set2.append(nodes1)
        nodeset.append(set2)

    set2 = nodeset[0].copy()
    len1 = len(nodeset)
    for i1 in range(1,len1):
        Freq = []
        for j1 in range(len(set2)):
            nodes1 = set2[j1]  # set2[j]
            for k1 in range(len(nodeset[i1])):
                nodes2 = nodeset[i1][k1]
                set1 = list(set(nodes1).intersection(nodes2))
                if len(set1) > 1:
                    Freq.append(set1)
        set2 = Freq.copy()

    return set2

#从随机解获取差集
def difference_sect(comm, num):

    nodeset = []
    # 通过节点对（同一个社区内的节点对）计算
    for j in num:
        set2 = []
        max1 = np.max(comm[j])+1
        for i in range(int(max1)):
            nodes1 = [k for (k, v) in enumerate(comm[j]) if v == i]
            if nodes1 != []:
                set2.append(nodes1)
        nodeset.append(set2)

    freq = []
    i = 0
    while (freq == []) & (i < 2):
        if i == 0:
            set2 = nodeset[0].copy()
            i1 = 1
        else:
            set2 = nodeset[1].copy()
            i1 = 0

        for j1 in range(len(set2)):
            nodes1 = set2[j1]
            temp = []
            argtemp = []
            for k1 in range(len(nodeset[i1])):
                nodes2 = nodeset[i1][k1]
                set1 = list(set(nodes1).intersection(set(nodes2)))
                #print("set1",set1)
                if set1 != []:
                    temp.append(len(set1))
                    argtemp.append(k1)
            maxmach = np.argmax(temp)
            argmaxmach = argtemp[maxmach]
            set3 = list(set(nodes1).difference(nodeset[i1][argmaxmach]))
            set4 = list(set(nodeset[i1][argmaxmach]).difference(nodes1))

            if len(set3) > 0:
                freq.append(set3)
            if len(set4) > 0:
                freq.append(set4)

            #if len(set3) > 0:
            #    for ii in set3:
            #        if ii not in freq:
            #            freq.append(ii)
            #if len(set4) > 0:
            #    for ii in set4:
            #        if ii not in freq:
            #            freq.append(ii)
        i += 1

    return freq

#从全局最优解获取差集
def difference_sect1(a,b):

    nodeset = []
    # 通过节点对（同一个社区内的节点对）计算
    set2 = []
    max1 = np.max(a)+1
    for i in range(int(max1)):
        nodes1 = [k for (k, v) in enumerate(a) if v == i]
        if nodes1 != []:
            set2.append(nodes1)
    nodeset.append(set2)
    set2 = []
    max1 = np.max(b) + 1
    for i in range(int(max1)):
        nodes1 = [k for (k, v) in enumerate(b) if v == i]
        if nodes1 != []:
            set2.append(nodes1)
    nodeset.append(set2)

    freq = []
    #把Xi中的独立模块（len==1）处理掉
    for i in nodeset[1]:
        if len(i) == 1:
            freq.append(i[0])
            nodeset[1].remove(i)

    set2 = nodeset[0].copy()
    i1 = 1
    choset = []
    #对剩下的模块进行匹配并获取差集
    for j1 in range(len(nodeset[i1])):
        nodes1 = nodeset[i1][j1]
        temp = 0
        for k1 in range(len(set2)):
            nodes2 = set2[k1]
            commlen = len(list(set(nodes1).intersection(nodes2)))
            if commlen > temp:
                temp = commlen
                choset = nodes2
        set1 = list(set(nodes1).difference(choset))
        if len(set1) > 0:
            for i in set1:
                freq.append(i)

    #去重
    freq = list(set(freq))

    return freq



if __name__ == '__main__':

    G = gh.load_graph("NSGA2/dataset/mtunis.txt")
    X=[[0,0,0,0,0,0,0,1,0,1,0,0,0,2,2,2,2,2,2,2],[0,1,0,2,2,0,1,3,2,3,2,4,2,5,5,5,4,6,7,7],[0,1,0,2,2,0,1,3,2,3,2,4,2,5,5,5,0,4,6,6]]
    X1=[[ 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2],[ 0, 1, 0, 2, 2, 0, 1, 3, 2, 3, 2, 4, 2, 5, 5, 5, 4, 6, 7, 7],[ 0, 1, 0, 2, 2, 0, 1, 3, 2, 3, 2, 4, 2, 5, 5, 5, 0, 4,6, 6]]
    X2=[[0,1,0,2,1,1,1,1,3,1,0,4,2,2,4,1,4,4,4,4],
        [0,1,2,3,1,1,1,4,2,1,2,5,5,3,5,5,5,5,5,5]]

    #commset1, rest1 = cal_Fre(X1, 3, 0, G)
    #commset2, rest2 = cal_Fre(X1, 3, 1, G)
    #print(commset1,rest1)
    #print(commset2,rest2)
    num = [0,1]
    diffset = difference_sect(X2,[0,1])
    print(diffset)