##MPMODE-SMCP
This is the full MPMODE-SMCP code and the experimental results.

The two data sets used for the experiment are also included

## How to get started
The software environment for the experiments is Python 3.7, and the relevant packages are available for download.
Once the above is complete. Run fitness_change.py and you can start the experiment.